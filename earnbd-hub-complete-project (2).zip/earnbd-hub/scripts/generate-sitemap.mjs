/**
 * Generates public/sitemap.xml and public/robots.txt before every production build (npm run build).
 *  - Static pages are always included.
 *  - If Firebase is configured, published posts and custom categories are fetched through the
 *    public Firestore REST API and added too.
 * The script never fails the build: on any error it falls back to static pages only.
 */
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

function readEnvFile(name) {
  const file = join(root, name);
  if (!existsSync(file)) return {};
  const out = {};
  for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
  return out;
}

const env = { ...readEnvFile('.env'), ...readEnvFile('.env.production'), ...process.env };
const siteUrl = (env.VITE_SITE_URL || '').replace(/\/+$/, '');
const base = siteUrl || 'https://your-domain.com';
if (!siteUrl) console.warn('[sitemap] VITE_SITE_URL is not set – using https://your-domain.com as a placeholder.');

const STATIC_ROUTES = [
  ['/', 'daily', '1.0'],
  ['/blog', 'daily', '0.9'],
  ['/categories', 'weekly', '0.7'],
  ['/ai-tools', 'daily', '0.8'],
  ['/online-income', 'daily', '0.8'],
  ['/freelancing', 'daily', '0.8'],
  ['/job-circular', 'daily', '0.8'],
  ['/education', 'daily', '0.8'],
  ['/about', 'monthly', '0.5'],
  ['/contact', 'monthly', '0.5'],
  ['/privacy-policy', 'yearly', '0.3'],
  ['/terms-and-conditions', 'yearly', '0.3'],
];
const BUILT_IN_CATEGORIES = new Set(['ai-tools', 'online-income', 'freelancing', 'job-circular', 'education']);

const projectId = env.VITE_FIREBASE_PROJECT_ID;
const endpoint = projectId ? `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents` : '';

const num = (v) => Number(v?.integerValue ?? v?.doubleValue ?? 0);

async function fetchPosts() {
  const res = await fetch(`${endpoint}:runQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      structuredQuery: {
        from: [{ collectionId: 'posts' }],
        where: { fieldFilter: { field: { fieldPath: 'status' }, op: 'EQUAL', value: { stringValue: 'published' } } },
        limit: 5000,
      },
    }),
  });
  if (!res.ok) throw new Error(`posts HTTP ${res.status}`);
  const rows = await res.json();
  return rows
    .filter((r) => r.document)
    .map((r) => ({
      slug: r.document.fields?.slug?.stringValue,
      updatedAt: num(r.document.fields?.updatedAt) || num(r.document.fields?.createdAt),
    }))
    .filter((p) => p.slug);
}

async function fetchCategories() {
  const res = await fetch(`${endpoint}/categories?pageSize=300`);
  if (!res.ok) throw new Error(`categories HTTP ${res.status}`);
  const json = await res.json();
  return (json.documents || []).map((d) => d.fields?.slug?.stringValue).filter(Boolean);
}

const today = new Date().toISOString().slice(0, 10);
const xmlEscape = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const entry = (path, changefreq, priority, lastmod = today) =>
  `  <url>\n    <loc>${xmlEscape(base + path)}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>${changefreq}</changefreq>\n    <priority>${priority}</priority>\n  </url>`;

const entries = STATIC_ROUTES.map(([p, c, pr]) => entry(p, c, pr));
let postCount = 0;

if (endpoint) {
  try {
    const [posts, cats] = await Promise.all([fetchPosts(), fetchCategories()]);
    for (const p of posts) {
      const lastmod = p.updatedAt ? new Date(p.updatedAt).toISOString().slice(0, 10) : today;
      entries.push(entry(`/blog/${encodeURIComponent(p.slug)}`, 'weekly', '0.7', lastmod));
    }
    for (const slug of cats) {
      if (!BUILT_IN_CATEGORIES.has(slug)) entries.push(entry(`/category/${encodeURIComponent(slug)}`, 'weekly', '0.6'));
    }
    postCount = posts.length;
  } catch (err) {
    console.warn(`[sitemap] Could not load dynamic URLs (${err.message}). Using static pages only.`);
  }
} else {
  console.warn('[sitemap] Firebase not configured – static pages only.');
}

writeFileSync(
  join(root, 'public', 'sitemap.xml'),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries.join('\n')}\n</urlset>\n`,
);

writeFileSync(
  join(root, 'public', 'robots.txt'),
  `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /search\n\nUser-agent: Mediapartners-Google\nAllow: /\n\nSitemap: ${base}/sitemap.xml\n`,
);

console.log(`[sitemap] ${entries.length} URLs written (${postCount} posts) for ${base}`);
