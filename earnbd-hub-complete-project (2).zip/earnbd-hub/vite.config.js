import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * Injects the Google AdSense loader + account meta tag into index.html at build/dev time
 * when VITE_ADSENSE_CLIENT is set. Having it in the static HTML (not added by JS) lets Google's
 * crawler verify the site and keeps the script async so it never blocks rendering.
 */
function adsensePlugin(client) {
  return {
    name: 'earnbd-adsense',
    transformIndexHtml() {
      if (!client) return [];
      return [
        { tag: 'meta', attrs: { name: 'google-adsense-account', content: client }, injectTo: 'head' },
        {
          tag: 'script',
          attrs: {
            async: true,
            src: `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${client}`,
            crossorigin: 'anonymous',
          },
          injectTo: 'head',
        },
      ];
    },
  };
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  return {
    plugins: [react(), adsensePlugin(env.VITE_ADSENSE_CLIENT)],
    server: { port: 5173, host: true },
    preview: { port: 4173, host: true },
    build: {
      target: 'es2020',
      sourcemap: false,
      cssCodeSplit: true,
      chunkSizeWarningLimit: 600,
      rollupOptions: {
        output: {
          // Keep vendor code in long-lived, cacheable chunks.
          manualChunks(id) {
            if (!id.includes('node_modules')) return undefined;
            if (id.includes('firebase') || id.includes('@firebase')) return 'firebase';
            if (id.includes('react-router') || id.includes('@remix-run')) return 'router';
            if (id.includes('react-dom') || id.includes('/react/') || id.includes('scheduler')) return 'react';
            if (id.includes('lucide-react')) return 'icons';
            return undefined;
          },
        },
      },
    },
  };
});
