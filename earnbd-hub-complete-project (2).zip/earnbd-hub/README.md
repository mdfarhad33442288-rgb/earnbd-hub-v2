# EarnBD Hub

A modern, SEO-optimised blog and content platform built with **React 18 + Vite + Tailwind CSS + Firebase** (Authentication, Firestore, Storage), with a full admin dashboard and Google AdSense placements.

Topics: AI Tools · Online Income · Freelancing · Job Circular · Education.

---

## Quick start

```bash
npm install
npm run dev
```

Open <http://localhost:5173>.

**No Firebase account is needed to try it.** With an empty `.env` the app runs in **Demo Mode**: 11 sample posts, categories, users and 30 days of analytics are stored in your browser (`localStorage`).

| | |
|---|---|
| Admin panel | <http://localhost:5173/admin> |
| Demo login | `admin@earnbd.demo` / `admin123` |

Demo Mode is for evaluation only. Its login is not secure, so never deploy to production without Firebase keys (see below).

---

## Features

**Website** – Home (hero, featured / latest / popular), Blog, Single Post, Categories, five topic landing pages (AI Tools, Online Income, Freelancing, Job Circular, Education), live Search, About, Contact, Privacy Policy, Terms & Conditions, 404 and error pages. Dark mode, newsletter, social sharing, breadcrumbs, pagination, related posts, table of contents, lazy-loaded images, loading skeletons, cookie-consent banner, back-to-top.

**Admin** – Login, dashboard, post list with search / filters, Markdown editor with live preview, draft / publish, featured and sponsored flags, SEO fields, image upload (Firebase Storage), category manager, user manager (roles), analytics (daily views, top posts, views per category) and an inbox (contact messages + subscriber CSV export).

**Monetization** – AdSense in five placements (header, sidebar, in-article, in-feed, footer), an affiliate products section and a sponsored-content section.

**SEO** – per-page title / description / canonical, Open Graph + Twitter cards, Schema.org JSON-LD (WebSite + SearchAction, Organization, BlogPosting, BreadcrumbList, CollectionPage, FAQPage), auto-generated `sitemap.xml` and `robots.txt`, semantic HTML, clean URLs.

**Performance** – route-level code splitting, Firebase loaded lazily (never on first paint), vendor chunk splitting, immutable asset caching headers, generated SVG covers (no image requests for posts without a cover), non-blocking fonts.

---

## Project structure

```
earnbd-hub/
├─ index.html                  # SEO defaults, theme bootstrap (no dark-mode flash)
├─ vite.config.js              # chunk splitting + AdSense tag injection
├─ tailwind.config.js          # blue/white theme, animations
├─ firebase.json               # Hosting, rules and cache headers
├─ firestore.rules             # Firestore security rules
├─ storage.rules               # Storage security rules
├─ firestore.indexes.json
├─ vercel.json · public/_redirects   # SPA rewrites for Vercel / Netlify
├─ scripts/generate-sitemap.mjs      # runs before every build
├─ public/                     # favicon, icons, OG image, manifest, robots, sitemap, ads.txt
└─ src/
   ├─ main.jsx · App.jsx       # providers + routes (lazy-loaded)
   ├─ config/                  # site.js (branding, nav, ads, affiliates) · landing.js (topic copy + FAQs)
   ├─ lib/                     # firebase init, utils, markdown renderer, search, cover art, consent, analytics
   ├─ services/                # db.js (data layer) · auth.js · demoStore.js
   ├─ context/                 # Theme, Data (shared posts/categories), Auth (admin only)
   ├─ hooks/                   # useAsync, usePagination
   ├─ components/              # layout/ ui/ ads/ admin/
   └─ pages/                   # public pages + admin/ pages
```

Pages never talk to Firebase directly: everything goes through `src/services/db.js`, which switches between Firebase and Demo Mode automatically.

---

## Connect Firebase (production)

1. Create a project at <https://console.firebase.google.com>.
2. **Build → Authentication → Sign-in method** → enable **Email/Password**.
3. **Build → Firestore Database** → create a database (production mode).
4. **Build → Storage** → get started. (Storage rules read the user's role from Firestore, so Firestore must exist first.)
5. **Project settings → Your apps → Web (`</>`)** → register an app and copy the config.
6. Copy `.env.example` to `.env` and fill in:

   ```env
   VITE_FIREBASE_API_KEY=...
   VITE_FIREBASE_AUTH_DOMAIN=...
   VITE_FIREBASE_PROJECT_ID=...
   VITE_FIREBASE_STORAGE_BUCKET=...
   VITE_FIREBASE_MESSAGING_SENDER_ID=...
   VITE_FIREBASE_APP_ID=...
   VITE_SITE_URL=https://your-domain.com
   ```

7. Set your project id in `.firebaserc`, then deploy the security rules:

   ```bash
   npm install -g firebase-tools
   firebase login
   firebase deploy --only firestore:rules,firestore:indexes,storage
   ```

8. Restart `npm run dev`. Demo Mode switches off automatically.

### Create your first admin

New sign-ups always get the role `user`; only an existing admin can promote someone (enforced by the rules). Bootstrap the first admin once:

1. Open `/admin/login`, choose **Create account**, and register with your email.
2. In **Firebase Console → Firestore → `users` → your user document**, change `role` from `user` to `admin`.
3. Sign out and sign in again. From now on you can promote others in **Admin → Users**.

(Optionally click **Add sample data** on the dashboard to create the default categories and 11 sample posts.)

---

## Deployment

Build output is a static site in `dist/`. `npm run build` first generates `sitemap.xml` and `robots.txt` using `VITE_SITE_URL` (and your published posts, when Firebase is configured).

### Firebase Hosting

```bash
npm run build
firebase deploy            # or: npm run deploy
```

`firebase.json` already includes SPA rewrites, security headers and long-term caching for `/assets`.

### Vercel

Import the repo → Framework preset **Vite** → add the `VITE_*` environment variables → Deploy. `vercel.json` handles SPA routing.

### Netlify

Build command `npm run build`, publish directory `dist`, add the `VITE_*` variables. `public/_redirects` handles SPA routing.

> Add your production domain under **Firebase → Authentication → Settings → Authorized domains**.

---

## Monetization

### Google AdSense

1. Apply at <https://adsense.google.com> and add your domain.
2. Set `VITE_ADSENSE_CLIENT=ca-pub-XXXXXXXXXXXXXXXX` in `.env`. The AdSense script and the `google-adsense-account` meta tag are then injected into the HTML automatically.
3. Create display ad units and put their numeric ids into `VITE_ADSENSE_SLOT_HEADER`, `_SIDEBAR`, `_IN_ARTICLE`, `_IN_FEED`, `_FOOTER`.
4. After approval, put your publisher id into `public/ads.txt`.

Slots with no id render nothing in production (no empty boxes); in dev they show a dashed placeholder so you can see the layout. The cookie banner switches AdSense to non-personalised ads when a visitor declines.

### Affiliate products

Edit `AFFILIATES` in `src/config/site.js` and replace each `url` with your tracked link. Links use `rel="sponsored nofollow"` and the section carries an affiliate disclosure.

### Sponsored content

Tick **Sponsored** on any post in the admin editor and it appears in the Sponsored section. Until then, "advertise with us" cards are shown (`SPONSOR_FALLBACKS` in `src/config/site.js`).

### Google Analytics (optional)

Set `VITE_GA_ID=G-XXXXXXXXXX`. GA loads only after the visitor accepts cookies.

---

## Customising

| What | Where |
|---|---|
| Site name, social links, navigation | `src/config/site.js` |
| Topic page headlines, FAQs | `src/config/landing.js` |
| Colours | `tailwind.config.js` → `colors.brand` |
| Logo / favicon / OG image | `src/components/ui/Logo.jsx`, `public/` |
| About, Privacy, Terms text | `src/pages/About.jsx`, `PrivacyPolicy.jsx`, `TermsConditions.jsx` |

Before launch: replace the placeholder contact email, social URLs and affiliate links, review the Privacy Policy and Terms for your situation, and replace the sample posts with your own content.

---

## Notes & limits

- Public pages load all published posts once and filter client-side. This is fast and cheap for hundreds of posts; for thousands, switch the list queries in `src/services/db.js` to paginated Firestore queries.
- View counters are incremented from the browser, rate-limited per session and constrained by the security rules (+1 only). They are good for trends, not for audited statistics.
- Deleting a user in **Admin → Users** removes the Firestore profile; delete the sign-in itself in Firebase Console → Authentication (this needs the Admin SDK and cannot be done safely from the browser).
- The site is a client-rendered SPA. Google renders JavaScript, and per-page meta tags are set at runtime. For maximum social-preview reliability on very large sites, consider adding prerendering later.

## Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start the dev server |
| `npm run build` | Generate sitemap/robots, then build to `dist/` |
| `npm run preview` | Preview the production build |
| `npm run sitemap` | Regenerate `sitemap.xml` and `robots.txt` only |
| `npm run deploy` | Build and deploy to Firebase |
