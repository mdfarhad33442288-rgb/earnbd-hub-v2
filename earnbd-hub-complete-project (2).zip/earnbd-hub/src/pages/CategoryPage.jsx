import { useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, ChevronDown } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import PostGrid from '../components/ui/PostGrid';
import Pagination from '../components/ui/Pagination';
import Sidebar from '../components/ui/Sidebar';
import CategoryIcon from '../components/ui/CategoryIcon';
import AffiliateSection from '../components/ui/AffiliateSection';
import AdSlot from '../components/ads/AdSlot';
import NotFound from './NotFound';
import { useData } from '../context/DataContext';
import { usePagination } from '../hooks/usePagination';
import { DEFAULT_CATEGORIES, SITE, categoryPath } from '../config/site';
import { LANDING } from '../config/landing';
import { absoluteUrl } from '../lib/utils';

/**
 * One component powers every category page:
 *  - /ai-tools, /online-income, /freelancing, /job-circular, /education  (slug passed as a prop)
 *  - /category/:slug                                                      (slug from the URL)
 */
export default function CategoryPage({ slug: slugProp }) {
  const { slug: slugParam } = useParams();
  const slug = slugProp || slugParam;
  const { posts, catMap, loading, error, refresh } = useData();

  const category = catMap[slug] || DEFAULT_CATEGORIES.find((c) => c.slug === slug);
  const landing = LANDING[slug];
  const list = useMemo(() => posts.filter((p) => p.category === slug), [posts, slug]);
  const { page, totalPages, pageItems, setPage } = usePagination(list, SITE.postsPerPage);

  if (!category && !loading) return <NotFound />;
  if (!category) return <PageHeader title="Loading…" crumbs={[{ label: 'Categories', to: '/categories' }]} />;

  const path = categoryPath(slug);
  const title = landing?.metaTitle || `${category.name} – Guides & Articles`;
  const jsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'CollectionPage',
      name: category.name,
      description: category.description,
      url: absoluteUrl(path),
    },
  ];
  if (landing?.faqs?.length) {
    jsonLd.push({
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: landing.faqs.map((f) => ({
        '@type': 'Question',
        name: f.q,
        acceptedAnswer: { '@type': 'Answer', text: f.a },
      })),
    });
  }

  return (
    <>
      <Seo title={page > 1 ? `${title} – Page ${page}` : title} description={landing?.intro || category.description} path={path} jsonLd={jsonLd} />
      <PageHeader
        eyebrow="Category"
        title={landing?.headline || category.name}
        subtitle={landing?.intro || category.description}
        crumbs={[{ label: 'Categories', to: '/categories' }, { label: category.name }]}
        icon={<CategoryIcon name={category.icon} className="h-7 w-7" />}
      >
        {landing?.highlights && (
          <ul className="mt-5 flex flex-wrap gap-2">
            {landing.highlights.map((h) => (
              <li key={h} className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-brand-700 shadow-soft dark:bg-slate-800 dark:text-brand-300">
                <CheckCircle2 className="h-3.5 w-3.5" /> {h}
              </li>
            ))}
          </ul>
        )}
      </PageHeader>

      <div className="container-page py-10">
        <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
          <div>
            <PostGrid
              posts={pageItems}
              loading={loading}
              error={error}
              onRetry={refresh}
              columns="sm:grid-cols-2"
              adEvery={4}
              emptyTitle={`No ${category.name} articles yet`}
              emptyMessage="New content is on the way. Check back soon!"
            />
            {!loading && !error && <Pagination page={page} totalPages={totalPages} onChange={setPage} className="mt-10" />}
          </div>
          <Sidebar />
        </div>

        {landing?.faqs?.length > 0 && (
          <section className="mx-auto mt-16 max-w-3xl" aria-labelledby="faq-heading">
            <h2 id="faq-heading" className="mb-5 text-center text-2xl sm:text-3xl">
              Frequently asked questions
            </h2>
            <div className="space-y-3">
              {landing.faqs.map((f) => (
                <details key={f.q} className="card group p-5 open:shadow-lift">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-semibold text-slate-900 dark:text-white">
                    {f.q}
                    <ChevronDown className="h-5 w-5 shrink-0 text-brand-600 transition group-open:rotate-180" />
                  </summary>
                  <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">{f.a}</p>
                </details>
              ))}
            </div>
          </section>
        )}

        <AdSlot slot="footer" className="mt-12" />
        <div className="mt-14">
          <AffiliateSection />
        </div>
      </div>
    </>
  );
}
