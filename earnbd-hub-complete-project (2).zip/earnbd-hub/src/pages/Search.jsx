import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import PostGrid from '../components/ui/PostGrid';
import PostCard from '../components/ui/PostCard';
import Pagination from '../components/ui/Pagination';
import Sidebar from '../components/ui/Sidebar';
import { useData } from '../context/DataContext';
import { usePagination } from '../hooks/usePagination';
import { searchPosts } from '../lib/search';
import { SITE } from '../config/site';

export default function Search() {
  const [params, setParams] = useSearchParams();
  const q = (params.get('q') || '').trim();
  const [input, setInput] = useState(q);
  const { posts, popular, loading, error, refresh } = useData();

  useEffect(() => setInput(q), [q]);

  const results = useMemo(() => searchPosts(posts, q), [posts, q]);
  const { page, totalPages, pageItems, setPage } = usePagination(results, SITE.postsPerPage);

  function onSubmit(e) {
    e.preventDefault();
    setParams(input.trim() ? { q: input.trim() } : {});
  }

  return (
    <>
      <Seo title={q ? `Search: ${q}` : 'Search'} description="Search articles on EarnBD Hub." path="/search" noindex />
      <PageHeader
        eyebrow="Search"
        title={q ? `Results for “${q}”` : 'Search the site'}
        subtitle={q && !loading ? `${results.length} ${results.length === 1 ? 'article' : 'articles'} found` : 'Find guides, tools and tutorials.'}
        crumbs={[{ label: 'Search' }]}
        icon={<SearchIcon className="h-7 w-7" />}
      >
        <form onSubmit={onSubmit} role="search" className="mt-6 flex max-w-xl gap-2">
          <label htmlFor="search-page-input" className="sr-only">
            Search articles
          </label>
          <input
            id="search-page-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="e.g. freelancing, AI prompts, scholarship…"
            className="input"
          />
          <button type="submit" className="btn btn-primary">
            Search
          </button>
        </form>
      </PageHeader>

      <div className="container-page py-10">
        <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
          <div>
            {!q ? (
              <>
                <h2 className="mb-4 text-xl">Popular right now</h2>
                <div className="grid gap-6 sm:grid-cols-2">
                  {popular.slice(0, 4).map((p) => (
                    <PostCard key={p.id} post={p} />
                  ))}
                </div>
              </>
            ) : (
              <>
                <PostGrid
                  posts={pageItems}
                  loading={loading}
                  error={error}
                  onRetry={refresh}
                  columns="sm:grid-cols-2"
                  emptyTitle={`No results for “${q}”`}
                  emptyMessage="Check your spelling or try a more general keyword."
                />
                {!loading && !error && <Pagination page={page} totalPages={totalPages} onChange={setPage} className="mt-10" />}
              </>
            )}
          </div>
          <Sidebar />
        </div>
      </div>
    </>
  );
}
