import { Link } from 'react-router-dom';
import { ArrowRight, LayoutGrid } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import CategoryIcon from '../components/ui/CategoryIcon';
import Reveal from '../components/ui/Reveal';
import { ErrorState } from '../components/ui/ErrorState';
import AdSlot from '../components/ads/AdSlot';
import { useData } from '../context/DataContext';
import { categoryPath } from '../config/site';

export default function Categories() {
  const { categories, posts, loading, error, refresh } = useData();

  return (
    <>
      <Seo
        title="All Categories"
        description="Explore every topic on EarnBD Hub – AI tools, online income, freelancing, job circulars, education and more."
        path="/categories"
      />
      <PageHeader
        eyebrow="Browse by topic"
        title="All categories"
        subtitle="Find guides organised by the topic you care about."
        crumbs={[{ label: 'Categories' }]}
        icon={<LayoutGrid className="h-7 w-7" />}
      />
      <div className="container-page py-10">
        {error ? (
          <ErrorState onRetry={refresh} />
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(loading ? [] : categories).map((c, i) => {
              const count = posts.filter((p) => p.category === c.slug).length;
              return (
                <Reveal key={c.id} delay={(i % 3) * 80}>
                  <Link to={categoryPath(c.slug)} className="card card-hover group flex h-full flex-col p-6">
                    <span className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-glow transition group-hover:scale-105">
                      <CategoryIcon name={c.icon} className="h-7 w-7" />
                    </span>
                    <h2 className="text-xl">{c.name}</h2>
                    <p className="mt-2 flex-1 text-sm text-slate-600 dark:text-slate-400">{c.description}</p>
                    <span className="mt-5 inline-flex items-center justify-between text-sm font-semibold text-brand-600 dark:text-brand-400">
                      <span>{count} {count === 1 ? 'article' : 'articles'}</span>
                      <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                    </span>
                  </Link>
                </Reveal>
              );
            })}
            {loading &&
              Array.from({ length: 6 }, (_, i) => <div key={i} className="skeleton h-52 rounded-2xl" />)}
          </div>
        )}
        <AdSlot slot="inFeed" className="mt-10" />
      </div>
    </>
  );
}
