import LegalPage from '../components/ui/LegalPage';
import { SITE } from '../config/site';

const sections = [
  {
    title: 'Acceptance of terms',
    body: [`By accessing or using ${SITE.name}, you agree to these Terms & Conditions. If you do not agree, please do not use the website.`],
  },
  {
    title: 'Use of the website',
    body: [
      'You agree to use the site only for lawful purposes. You must not:',
      [
        'attempt to gain unauthorised access to the site, its servers or user accounts;',
        'upload malicious code or interfere with normal operation;',
        'scrape or copy content in bulk without written permission;',
        'use the site to send spam or unlawful, harmful or misleading content.',
      ],
    ],
  },
  {
    title: 'Informational content only',
    body: [
      'All articles are provided for general information and education. They are not professional financial, legal, medical or career advice. Earnings, job and study outcomes are never guaranteed and depend on your own effort, skills and circumstances. Always verify job circulars, deadlines and requirements with the official source before acting.',
    ],
  },
  {
    title: 'Intellectual property',
    body: [
      `Unless stated otherwise, the content, design, logo and code of ${SITE.name} are owned by us and protected by copyright. You may share short excerpts with a link back to the original article, but you may not republish full articles without permission.`,
    ],
  },
  {
    title: 'Advertising, affiliate and sponsored content',
    body: [
      'The site displays third-party ads and may include affiliate links and sponsored posts. We may earn compensation when you click or purchase. Sponsored content is labelled. We are not responsible for the products, services or content of advertisers or linked websites.',
    ],
  },
  {
    title: 'User accounts and submissions',
    body: [
      'If you create an account, you are responsible for keeping your credentials secure and for all activity under your account. Messages and other content you submit must be accurate and must not infringe anyone’s rights. We may suspend or delete accounts that violate these terms.',
    ],
  },
  {
    title: 'Disclaimer of warranties',
    body: [
      'The website and its content are provided “as is” and “as available”, without warranties of any kind. We do not guarantee that the site will be uninterrupted, error-free or that information is always complete or up to date.',
    ],
  },
  {
    title: 'Limitation of liability',
    body: [
      `To the fullest extent permitted by law, ${SITE.name} and its owners are not liable for any indirect, incidental or consequential damages arising from your use of, or inability to use, the website or reliance on its content.`,
    ],
  },
  {
    title: 'Changes to these terms',
    body: ['We may update these terms at any time. Continued use of the website after changes means you accept the updated terms.'],
  },
  {
    title: 'Governing law and contact',
    body: [
      'These terms are governed by the laws of Bangladesh. If you have any questions, contact us at ' + SITE.email + '.',
    ],
  },
];

export default function TermsConditions() {
  return (
    <LegalPage
      title="Terms & Conditions"
      description={`The terms that apply when you use ${SITE.name}, including content use, advertising and disclaimers.`}
      path="/terms-and-conditions"
      updated="November 21, 2026"
      intro={`Welcome to ${SITE.name}. Please read these terms carefully before using our website.`}
      sections={sections}
    />
  );
}
