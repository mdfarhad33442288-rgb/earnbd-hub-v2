import { useState } from 'react';
import { Download, Mail, MessageSquare, Reply, Trash2 } from 'lucide-react';
import { AdminPageHeader } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { EmptyState, ErrorState } from '../../components/ui/ErrorState';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { useAsync } from '../../hooks/useAsync';
import { deleteMessage, deleteSubscriber, listMessages, listSubscribers } from '../../services/db';
import { formatDate } from '../../lib/utils';

const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

function downloadCsv(rows) {
  const lines = ['email,source,subscribed_on', ...rows.map((r) => [r.email, r.source, new Date(r.createdAt).toISOString()].map(csvCell).join(','))];
  const url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `subscribers-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function AdminInbox() {
  const { toast } = useToast();
  const [tab, setTab] = useState('messages');
  const [toDelete, setToDelete] = useState(null); // { kind, row }
  const [busy, setBusy] = useState(false);

  const { data, loading, error, reload } = useAsync(async () => {
    const [messages, subscribers] = await Promise.all([listMessages(), listSubscribers()]);
    return { messages, subscribers };
  }, []);

  async function onDelete() {
    setBusy(true);
    try {
      if (toDelete.kind === 'messages') await deleteMessage(toDelete.row.id);
      else await deleteSubscriber(toDelete.row.id);
      toast('Deleted.');
      setToDelete(null);
      reload();
    } catch (err) {
      toast(err.message || 'Could not delete.', 'error');
    } finally {
      setBusy(false);
    }
  }

  const header = <AdminPageHeader title="Inbox" subtitle="Contact-form messages and newsletter subscribers." />;

  if (error) {
    return (
      <>
        {header}
        <ErrorState title="Could not load the inbox" message={error.message} onRetry={reload} />
      </>
    );
  }

  const tabs = [
    { id: 'messages', label: 'Messages', icon: MessageSquare, count: data?.messages.length },
    { id: 'subscribers', label: 'Subscribers', icon: Mail, count: data?.subscribers.length },
  ];

  return (
    <>
      {header}

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-xl border border-slate-200 bg-white p-1 dark:border-slate-700 dark:bg-slate-900" role="tablist">
          {tabs.map(({ id, label, icon: Icon, count }) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              onClick={() => setTab(id)}
              className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
                tab === id ? 'bg-brand-600 text-white shadow-soft' : 'text-slate-600 hover:text-brand-700 dark:text-slate-300'
              }`}
            >
              <Icon className="h-4 w-4" /> {label}
              {count !== undefined && <span className={`rounded-full px-2 text-xs ${tab === id ? 'bg-white/20' : 'bg-slate-100 dark:bg-slate-800'}`}>{count}</span>}
            </button>
          ))}
        </div>
        {tab === 'subscribers' && data?.subscribers.length > 0 && (
          <button type="button" className="btn btn-outline btn-sm" onClick={() => downloadCsv(data.subscribers)}>
            <Download className="h-4 w-4" /> Export CSV
          </button>
        )}
      </div>

      {loading ? (
        <div className="card"><TableSkeleton rows={5} /></div>
      ) : tab === 'messages' ? (
        !data.messages.length ? (
          <EmptyState title="No messages yet" message="Messages sent from the Contact page will appear here." />
        ) : (
          <ul className="space-y-4">
            {data.messages.map((m) => (
              <li key={m.id} className="card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-base">{m.subject}</h3>
                    <p className="mt-0.5 text-sm text-slate-500">
                      {m.name} · <a className="text-brand-600 hover:underline" href={`mailto:${m.email}`}>{m.email}</a> · {formatDate(m.createdAt, { dateStyle: 'medium', timeStyle: 'short' })}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <a className="btn btn-outline btn-sm" href={`mailto:${m.email}?subject=${encodeURIComponent(`Re: ${m.subject}`)}`}>
                      <Reply className="h-4 w-4" /> Reply
                    </a>
                    <button type="button" className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10" aria-label="Delete message" onClick={() => setToDelete({ kind: 'messages', row: m })}>
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-7 text-slate-700 dark:text-slate-300">{m.message}</p>
              </li>
            ))}
          </ul>
        )
      ) : !data.subscribers.length ? (
        <EmptyState title="No subscribers yet" message="Sign-ups from the newsletter forms will appear here." />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:border-slate-800 dark:bg-slate-900/60">
                <tr>
                  <th className="px-5 py-3 font-semibold">Email</th>
                  <th className="px-5 py-3 font-semibold">Source</th>
                  <th className="px-5 py-3 font-semibold">Subscribed</th>
                  <th className="px-5 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {data.subscribers.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-5 py-3 font-medium text-slate-900 dark:text-white">{s.email}</td>
                    <td className="px-5 py-3 text-slate-500">{s.source || '—'}</td>
                    <td className="whitespace-nowrap px-5 py-3 text-slate-500">{formatDate(s.createdAt)}</td>
                    <td className="px-5 py-3 text-right">
                      <button type="button" className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10" aria-label={`Remove ${s.email}`} onClick={() => setToDelete({ kind: 'subscribers', row: s })}>
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(toDelete)}
        busy={busy}
        title={toDelete?.kind === 'messages' ? 'Delete this message?' : 'Remove this subscriber?'}
        message="This cannot be undone."
        onConfirm={onDelete}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
