import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Eye, Pencil, PlusCircle, Search, Star, Trash2 } from 'lucide-react';
import { AdminPageHeader, StatusBadge } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { EmptyState, ErrorState } from '../../components/ui/ErrorState';
import Pagination from '../../components/ui/Pagination';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import LazyImage from '../../components/ui/LazyImage';
import { useToast } from '../../components/ui/Toast';
import { useAsync } from '../../hooks/useAsync';
import { deletePost, listCategories, listPosts, savePost } from '../../services/db';
import { postCover } from '../../lib/cover';
import { formatDate, formatNumber } from '../../lib/utils';

const PER_PAGE = 10;

export default function AdminPosts() {
  const { toast } = useToast();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [category, setCategory] = useState('all');
  const [page, setPage] = useState(1);
  const [toDelete, setToDelete] = useState(null);
  const [busy, setBusy] = useState(false);

  const { data, loading, error, reload } = useAsync(async () => {
    const [posts, categories] = await Promise.all([listPosts({ drafts: true }), listCategories()]);
    return { posts, categories };
  }, []);

  const catName = (slug) => data?.categories.find((c) => c.slug === slug)?.name || slug || '—';

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (data?.posts || []).filter(
      (p) =>
        (status === 'all' || p.status === status) &&
        (category === 'all' || p.category === category) &&
        (!q || p.title.toLowerCase().includes(q) || p.slug.includes(q)),
    );
  }, [data, query, status, category]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const current = Math.min(page, totalPages);
  const rows = filtered.slice((current - 1) * PER_PAGE, current * PER_PAGE);

  async function confirmDelete() {
    setBusy(true);
    try {
      await deletePost(toDelete.id);
      toast('Post deleted.');
      setToDelete(null);
      reload();
    } catch (err) {
      toast(err.message || 'Could not delete the post.', 'error');
    } finally {
      setBusy(false);
    }
  }

  async function toggleFeatured(post) {
    try {
      await savePost({ ...post, featured: !post.featured });
      toast(post.featured ? 'Removed from featured.' : 'Marked as featured.');
      reload();
    } catch (err) {
      toast(err.message || 'Could not update the post.', 'error');
    }
  }

  const reset = (fn) => (e) => {
    fn(e.target.value);
    setPage(1);
  };

  return (
    <>
      <AdminPageHeader
        title="Posts"
        subtitle={`${data?.posts.length ?? 0} total`}
        actions={
          <Link to="/admin/posts/new" className="btn btn-primary btn-sm">
            <PlusCircle className="h-4 w-4" /> New post
          </Link>
        }
      />

      <div className="card mb-5 grid gap-3 p-4 sm:grid-cols-[1fr_auto_auto]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input value={query} onChange={reset(setQuery)} placeholder="Search posts…" className="input !pl-10" aria-label="Search posts" />
        </div>
        <select value={status} onChange={reset(setStatus)} className="input sm:w-40" aria-label="Filter by status">
          <option value="all">All statuses</option>
          <option value="published">Published</option>
          <option value="draft">Drafts</option>
        </select>
        <select value={category} onChange={reset(setCategory)} className="input sm:w-48" aria-label="Filter by category">
          <option value="all">All categories</option>
          {(data?.categories || []).map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {error ? (
        <ErrorState message={error.message} onRetry={reload} />
      ) : loading ? (
        <div className="card">
          <TableSkeleton />
        </div>
      ) : !filtered.length ? (
        <EmptyState title="No posts found" message="Try changing your filters or create a new post.">
          <Link to="/admin/posts/new" className="btn btn-primary btn-sm">
            <PlusCircle className="h-4 w-4" /> New post
          </Link>
        </EmptyState>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[44rem]">
              <thead className="border-b border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/60">
                <tr>
                  <th className="th">Post</th>
                  <th className="th">Category</th>
                  <th className="th">Status</th>
                  <th className="th">Views</th>
                  <th className="th">Date</th>
                  <th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {rows.map((p) => (
                  <tr key={p.id} className="transition hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="td">
                      <div className="flex items-center gap-3">
                        <span className="block aspect-[4/3] w-14 shrink-0 overflow-hidden rounded-lg">
                          <LazyImage src={postCover(p)} alt="" fallbackSeed={p.slug} />
                        </span>
                        <div className="min-w-0">
                          <Link to={`/admin/posts/${p.id}/edit`} className="line-clamp-1 font-semibold text-slate-900 hover:text-brand-600 dark:text-slate-100">
                            {p.title}
                          </Link>
                          <p className="line-clamp-1 text-xs text-slate-500">/blog/{p.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td className="td whitespace-nowrap">{catName(p.category)}</td>
                    <td className="td">
                      <StatusBadge status={p.status} />
                    </td>
                    <td className="td whitespace-nowrap">
                      <span className="inline-flex items-center gap-1 text-slate-500">
                        <Eye className="h-4 w-4" /> {formatNumber(p.views)}
                      </span>
                    </td>
                    <td className="td whitespace-nowrap text-slate-500">{formatDate(p.createdAt)}</td>
                    <td className="td">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => toggleFeatured(p)}
                          className={`rounded-lg p-2 transition hover:bg-slate-100 dark:hover:bg-slate-800 ${p.featured ? 'text-amber-500' : 'text-slate-400'}`}
                          aria-label={p.featured ? 'Remove from featured' : 'Mark as featured'}
                          title={p.featured ? 'Featured' : 'Mark as featured'}
                        >
                          <Star className={`h-4 w-4 ${p.featured ? 'fill-current' : ''}`} />
                        </button>
                        {p.status === 'published' && (
                          <Link to={`/blog/${p.slug}`} target="_blank" className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-100 hover:text-brand-600 dark:hover:bg-slate-800" aria-label="View post" title="View">
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                        )}
                        <Link to={`/admin/posts/${p.id}/edit`} className="rounded-lg p-2 text-slate-400 transition hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-slate-800" aria-label="Edit post" title="Edit">
                          <Pencil className="h-4 w-4" />
                        </Link>
                        <button type="button" onClick={() => setToDelete(p)} className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10" aria-label="Delete post" title="Delete">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && <Pagination page={current} totalPages={totalPages} onChange={setPage} className="border-t border-slate-100 p-4 dark:border-slate-800" />}
        </div>
      )}

      <ConfirmDialog
        open={Boolean(toDelete)}
        busy={busy}
        title="Delete this post?"
        message={toDelete ? `“${toDelete.title}” will be permanently deleted. This cannot be undone.` : ''}
        onConfirm={confirmDelete}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
