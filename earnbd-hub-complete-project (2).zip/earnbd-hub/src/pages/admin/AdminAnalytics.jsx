import { useState } from 'react';
import { Eye, FileText, Flame, Mail, TrendingUp } from 'lucide-react';
import { AdminPageHeader, BarChart, StatCard } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { ErrorState } from '../../components/ui/ErrorState';
import { useAsync } from '../../hooks/useAsync';
import { getDailyViews, listCategories, listPosts, listSubscribers } from '../../services/db';
import { formatDate, formatNumber } from '../../lib/utils';

const RANGES = [7, 14, 30];

export default function AdminAnalytics() {
  const [days, setDays] = useState(14);

  const { data, loading, error, reload } = useAsync(async () => {
    const [daily, posts, categories, subscribers] = await Promise.all([
      getDailyViews(days),
      listPosts({ drafts: true }),
      listCategories(),
      listSubscribers(),
    ]);
    return { daily, posts, categories, subscribers };
  }, [days]);

  const header = (
    <AdminPageHeader
      title="Analytics"
      subtitle="Page views and content performance. Connect Google Analytics (VITE_GA_ID) for deeper audience reports."
      actions={
        <div className="inline-flex rounded-xl border border-slate-200 bg-white p-1 dark:border-slate-700 dark:bg-slate-900" role="group" aria-label="Date range">
          {RANGES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setDays(r)}
              aria-pressed={days === r}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                days === r ? 'bg-brand-600 text-white shadow-soft' : 'text-slate-600 hover:text-brand-700 dark:text-slate-300'
              }`}
            >
              {r} days
            </button>
          ))}
        </div>
      }
    />
  );

  if (error) {
    return (
      <>
        {header}
        <ErrorState title="Could not load analytics" message={error.message} onRetry={reload} />
      </>
    );
  }
  if (loading && !data) {
    return (
      <>
        {header}
        <div className="card"><TableSkeleton rows={8} /></div>
      </>
    );
  }

  const { daily, posts, categories, subscribers } = data;
  const total = daily.reduce((s, d) => s + d.views, 0);
  const avg = Math.round(total / Math.max(1, daily.length));
  const best = daily.reduce((b, d) => (d.views > b.views ? d : b), daily[0] || { date: '', views: 0 });
  const published = posts.filter((p) => p.status === 'published');
  const top = [...published].sort((a, b) => b.views - a.views).slice(0, 8);
  const topMax = Math.max(1, top[0]?.views || 1);

  const byCategory = categories
    .map((c) => {
      const list = published.filter((p) => p.category === c.slug);
      return { name: c.name, posts: list.length, views: list.reduce((s, p) => s + p.views, 0) };
    })
    .sort((a, b) => b.views - a.views);
  const catMax = Math.max(1, ...byCategory.map((c) => c.views));

  return (
    <div className={loading ? 'opacity-60 transition' : 'transition'}>
      {header}

      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard icon={Eye} label={`Page views (${days}d)`} value={formatNumber(total)} hint={`${avg.toLocaleString()} per day on average`} />
          <StatCard icon={Flame} label="Best day" value={formatNumber(best.views)} hint={best.date ? formatDate(best.date) : '—'} tone="rose" />
          <StatCard icon={FileText} label="Published posts" value={published.length} hint={`${posts.length - published.length} drafts`} tone="green" />
          <StatCard icon={Mail} label="Newsletter subscribers" value={subscribers.length} hint="All time" tone="amber" />
        </div>

        <section className="card p-5">
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-brand-600" />
            <h2 className="text-lg">Daily page views</h2>
          </div>
          <BarChart data={daily.map((d) => ({ label: d.date.slice(5), value: d.views }))} height={230} />
        </section>

        <div className="grid gap-6 xl:grid-cols-2">
          <section className="card p-5">
            <h2 className="mb-4 text-lg">Most-read posts</h2>
            {top.length ? (
              <ol className="space-y-4">
                {top.map((p, i) => (
                  <li key={p.id}>
                    <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                      <span className="min-w-0 truncate font-semibold text-slate-900 dark:text-slate-100">
                        <span className="mr-2 text-slate-400">{i + 1}.</span>
                        {p.title}
                      </span>
                      <span className="shrink-0 text-slate-500">{formatNumber(p.views)}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-gradient-to-r from-brand-600 to-sky-400" style={{ width: `${(p.views / topMax) * 100}%` }} />
                    </div>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="py-6 text-center text-sm text-slate-500">No published posts yet.</p>
            )}
          </section>

          <section className="card p-5">
            <h2 className="mb-4 text-lg">Views by category</h2>
            {byCategory.length ? (
              <ul className="space-y-4">
                {byCategory.map((c) => (
                  <li key={c.name}>
                    <div className="mb-1.5 flex items-center justify-between gap-3 text-sm">
                      <span className="font-semibold text-slate-900 dark:text-slate-100">
                        {c.name} <span className="font-normal text-slate-400">· {c.posts} posts</span>
                      </span>
                      <span className="text-slate-500">{formatNumber(c.views)}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                      <div className="h-full rounded-full bg-gradient-to-r from-sky-500 to-brand-700" style={{ width: `${(c.views / catMax) * 100}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="py-6 text-center text-sm text-slate-500">No categories yet.</p>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
