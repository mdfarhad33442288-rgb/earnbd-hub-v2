import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Pencil, PlusCircle, Trash2, X } from 'lucide-react';
import { AdminPageHeader } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { EmptyState, ErrorState } from '../../components/ui/ErrorState';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import CategoryIcon, { ICONS } from '../../components/ui/CategoryIcon';
import { useToast } from '../../components/ui/Toast';
import { useAsync } from '../../hooks/useAsync';
import { deleteCategory, listCategories, listPosts, saveCategory } from '../../services/db';
import { categoryPath } from '../../config/site';
import { slugify } from '../../lib/utils';

const EMPTY = { id: '', name: '', slug: '', description: '', icon: 'folder' };

export default function AdminCategories() {
  const { toast } = useToast();
  const [form, setForm] = useState(null); // null = closed, object = open
  const [saving, setSaving] = useState(false);
  const [toDelete, setToDelete] = useState(null);

  const { data, loading, error, reload } = useAsync(async () => {
    const [categories, posts] = await Promise.all([listCategories(), listPosts({ drafts: true })]);
    const counts = {};
    posts.forEach((p) => {
      counts[p.category] = (counts[p.category] || 0) + 1;
    });
    return { categories, counts };
  }, []);

  const editing = Boolean(form?.id);
  const set = (key) => (e) => {
    const value = e.target.value;
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (key === 'name' && !editing) next.slug = slugify(value);
      return next;
    });
  };

  async function onSubmit(e) {
    e.preventDefault();
    setSaving(true);
    try {
      await saveCategory(form);
      toast(editing ? 'Category updated.' : 'Category created.');
      setForm(null);
      reload();
    } catch (err) {
      toast(err.message || 'Could not save the category.', 'error');
    } finally {
      setSaving(false);
    }
  }

  async function onDelete() {
    setSaving(true);
    try {
      await deleteCategory(toDelete.id);
      toast('Category deleted.');
      setToDelete(null);
      reload();
    } catch (err) {
      toast(err.message || 'Could not delete the category.', 'error');
    } finally {
      setSaving(false);
    }
  }

  const header = (
    <AdminPageHeader
      title="Categories"
      subtitle="Group your posts. The five core categories power the main navigation pages."
      actions={
        <button type="button" className="btn btn-primary btn-sm" onClick={() => setForm({ ...EMPTY })}>
          <PlusCircle className="h-4 w-4" /> New category
        </button>
      }
    />
  );

  if (error) {
    return (
      <>
        {header}
        <ErrorState title="Could not load categories" message={error.message} onRetry={reload} />
      </>
    );
  }

  return (
    <>
      {header}

      {form && (
        <form onSubmit={onSubmit} className="card mb-6 animate-fade-up p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg">{editing ? 'Edit category' : 'New category'}</h2>
            <button type="button" onClick={() => setForm(null)} className="rounded-lg p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close form">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="cat-name" className="label">Name</label>
              <input id="cat-name" className="input" value={form.name} onChange={set('name')} required maxLength={60} placeholder="e.g. Scholarships" />
            </div>
            <div>
              <label htmlFor="cat-slug" className="label">Slug (URL)</label>
              <input id="cat-slug" className="input" value={form.slug} onChange={set('slug')} required disabled={editing} maxLength={60} placeholder="scholarships" />
              {editing && <p className="mt-1 text-xs text-slate-500">The slug can’t be changed after creation.</p>}
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="cat-desc" className="label">Description</label>
              <textarea id="cat-desc" className="input min-h-[84px]" value={form.description} onChange={set('description')} maxLength={220} placeholder="One or two sentences shown on the category page." />
            </div>
            <div className="sm:col-span-2">
              <span className="label">Icon</span>
              <div className="flex flex-wrap gap-2">
                {Object.keys(ICONS).map((name) => (
                  <button
                    key={name}
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, icon: name }))}
                    aria-pressed={form.icon === name}
                    aria-label={`Icon ${name}`}
                    className={`grid h-11 w-11 place-items-center rounded-xl border transition ${
                      form.icon === name
                        ? 'border-brand-600 bg-brand-600 text-white shadow-glow'
                        : 'border-slate-200 text-slate-600 hover:border-brand-300 dark:border-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <CategoryIcon name={name} />
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-5 flex justify-end gap-3">
            <button type="button" className="btn btn-outline" onClick={() => setForm(null)}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving…' : editing ? 'Save changes' : 'Create category'}
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <div className="card"><TableSkeleton rows={6} /></div>
      ) : !data.categories.length ? (
        <EmptyState title="No categories yet" message="Create your first category to organise posts." />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:border-slate-800 dark:bg-slate-900/60">
                <tr>
                  <th className="px-5 py-3 font-semibold">Category</th>
                  <th className="px-5 py-3 font-semibold">Slug</th>
                  <th className="px-5 py-3 font-semibold">Posts</th>
                  <th className="px-5 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {data.categories.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15">
                          <CategoryIcon name={c.icon} />
                        </span>
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-900 dark:text-white">{c.name}</p>
                          <p className="line-clamp-1 text-xs text-slate-500">{c.description || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 font-mono text-xs text-slate-500">{c.slug}</td>
                    <td className="px-5 py-3">
                      <Link to={`/admin/posts`} className="font-semibold text-brand-600 hover:underline">
                        {data.counts[c.slug] || 0}
                      </Link>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1">
                        <Link to={categoryPath(c.slug)} target="_blank" className="btn btn-ghost btn-sm">View</Link>
                        <button type="button" onClick={() => setForm({ ...EMPTY, ...c })} className="rounded-lg p-2 text-slate-400 transition hover:bg-brand-50 hover:text-brand-600 dark:hover:bg-slate-800" aria-label={`Edit ${c.name}`}>
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button type="button" onClick={() => setToDelete(c)} className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-500/10" aria-label={`Delete ${c.name}`}>
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(toDelete)}
        busy={saving}
        title={`Delete “${toDelete?.name}”?`}
        message={
          (data?.counts[toDelete?.slug] || 0) > 0
            ? `${data.counts[toDelete.slug]} post(s) use this category. They will stay online but show as uncategorised.`
            : 'This category has no posts.'
        }
        onConfirm={onDelete}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
