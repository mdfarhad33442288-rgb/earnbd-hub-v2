import { useMemo, useState } from 'react';
import { Search, ShieldCheck, Trash2, User } from 'lucide-react';
import { AdminPageHeader } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { EmptyState, ErrorState } from '../../components/ui/ErrorState';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { useAuth } from '../../context/AuthContext';
import { useAsync } from '../../hooks/useAsync';
import { deleteUserProfile, isDemo, listUsers, updateUserRole } from '../../services/db';
import { formatDate } from '../../lib/utils';

export default function AdminUsers() {
  const { toast } = useToast();
  const { user: me } = useAuth();
  const [query, setQuery] = useState('');
  const [toDelete, setToDelete] = useState(null);
  const [busy, setBusy] = useState(false);

  const { data, loading, error, reload } = useAsync(listUsers, []);

  const users = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (data || []).filter((u) => !q || u.email?.toLowerCase().includes(q) || u.displayName?.toLowerCase().includes(q));
  }, [data, query]);

  async function onRole(u, role) {
    try {
      await updateUserRole(u.uid, role);
      toast(`${u.displayName || u.email} is now ${role === 'admin' ? 'an admin' : 'a regular user'}.`);
      reload();
    } catch (err) {
      toast(err.message || 'Could not change the role.', 'error');
    }
  }

  async function onDelete() {
    setBusy(true);
    try {
      await deleteUserProfile(toDelete.uid);
      toast('User profile removed.');
      setToDelete(null);
      reload();
    } catch (err) {
      toast(err.message || 'Could not remove the user.', 'error');
    } finally {
      setBusy(false);
    }
  }

  const header = <AdminPageHeader title="Users" subtitle="Promote trusted people to admin or remove accounts you no longer need." />;

  if (error) {
    return (
      <>
        {header}
        <ErrorState title="Could not load users" message={error.message} onRetry={reload} />
      </>
    );
  }

  return (
    <>
      {header}

      <div className="relative mb-4 max-w-sm">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input type="search" className="input pl-10" placeholder="Search name or email…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search users" />
      </div>

      {loading ? (
        <div className="card"><TableSkeleton rows={6} /></div>
      ) : !users.length ? (
        <EmptyState title="No users found" message={query ? 'Try a different search.' : 'Users appear here after they create an account.'} />
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500 dark:border-slate-800 dark:bg-slate-900/60">
                <tr>
                  <th className="px-5 py-3 font-semibold">User</th>
                  <th className="px-5 py-3 font-semibold">Role</th>
                  <th className="px-5 py-3 font-semibold">Joined</th>
                  <th className="px-5 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => {
                  const isMe = u.uid === me?.uid;
                  return (
                    <tr key={u.uid} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-3">
                          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 font-bold text-white">
                            {(u.displayName || u.email || '?').charAt(0).toUpperCase()}
                          </span>
                          <div className="min-w-0">
                            <p className="truncate font-semibold text-slate-900 dark:text-white">
                              {u.displayName || 'Unnamed'} {isMe && <span className="ml-1 text-xs font-medium text-brand-600">(you)</span>}
                            </p>
                            <p className="truncate text-xs text-slate-500">{u.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
                            u.role === 'admin'
                              ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300'
                              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {u.role === 'admin' ? <ShieldCheck className="h-3.5 w-3.5" /> : <User className="h-3.5 w-3.5" />}
                          {u.role === 'admin' ? 'Admin' : 'User'}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-5 py-3 text-slate-500">{formatDate(u.createdAt)}</td>
                      <td className="px-5 py-3">
                        <div className="flex items-center justify-end gap-2">
                          <select
                            className="input !w-auto !py-1.5 text-xs"
                            value={u.role}
                            disabled={isMe}
                            onChange={(e) => onRole(u, e.target.value)}
                            aria-label={`Role for ${u.email}`}
                            title={isMe ? 'You cannot change your own role' : 'Change role'}
                          >
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                          </select>
                          <button
                            type="button"
                            disabled={isMe}
                            onClick={() => setToDelete(u)}
                            className="rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40 dark:hover:bg-red-500/10"
                            aria-label={`Remove ${u.email}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {!isDemo && (
        <p className="mt-4 text-xs text-slate-500">
          Removing a user deletes their profile and role. To also delete the sign-in account, remove it in Firebase Console → Authentication.
        </p>
      )}

      <ConfirmDialog
        open={Boolean(toDelete)}
        busy={busy}
        title="Remove this user?"
        message={toDelete ? `${toDelete.displayName || toDelete.email} will lose access to their profile.` : ''}
        confirmLabel="Remove"
        onConfirm={onDelete}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
