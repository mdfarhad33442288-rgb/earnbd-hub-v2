import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Info, Loader2, Lock, Mail, ShieldCheck, User } from 'lucide-react';
import Seo from '../../components/ui/Seo';
import Logo from '../../components/ui/Logo';
import { useAuth } from '../../context/AuthContext';
import { authErrorMessage } from '../../services/auth';
import { isDemo } from '../../services/db';
import { DEMO_ADMIN } from '../../services/demoStore';

export default function AdminLogin() {
  const { user, isAdmin, login, register, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const redirectTo = location.state?.from || '/admin';

  const [mode, setMode] = useState('signin'); // 'signin' | 'signup'
  const [form, setForm] = useState({ name: '', email: isDemo ? DEMO_ADMIN.email : '', password: isDemo ? DEMO_ADMIN.password : '' });
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user && isAdmin) navigate(redirectTo, { replace: true });
  }, [user, isAdmin, navigate, redirectTo]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (mode === 'signin') await login(form.email.trim(), form.password);
      else await register(form.email.trim(), form.password, form.name.trim());
    } catch (err) {
      setError(authErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden bg-gradient-to-br from-brand-700 via-brand-800 to-brand-950 px-4 py-10">
      <Seo title="Admin Login" noindex path="/admin/login" />
      <div className="pointer-events-none absolute -left-20 -top-20 h-80 w-80 animate-blob rounded-full bg-sky-400/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-10 h-96 w-96 animate-blob rounded-full bg-brand-400/30 blur-3xl" />

      <div className="relative w-full max-w-md animate-fade-up">
        <div className="mb-6 flex justify-center">
          <Logo light />
        </div>
        <div className="card p-6 sm:p-8">
          <div className="mb-6 text-center">
            <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/15">
              <ShieldCheck className="h-6 w-6" />
            </span>
            <h1 className="text-2xl">{mode === 'signin' ? 'Admin sign in' : 'Create an account'}</h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {mode === 'signin' ? 'Sign in to manage your website.' : 'Reader accounts do not have admin access until promoted.'}
            </p>
          </div>

          {isDemo && (
            <div className="mb-5 flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-xs text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200">
              <Info className="mt-0.5 h-4 w-4 shrink-0" />
              <p>
                <strong>Demo mode</strong> (Firebase not configured). Sign in with <code className="font-bold">{DEMO_ADMIN.email}</code> /{' '}
                <code className="font-bold">{DEMO_ADMIN.password}</code> – already filled in for you.
              </p>
            </div>
          )}

          {user && !isAdmin && (
            <div role="alert" className="mb-5 rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-sm text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200">
              You are signed in as <strong>{user.email}</strong>, but this account is not an administrator.{' '}
              <button type="button" className="font-semibold underline" onClick={() => logout()}>
                Sign out
              </button>
            </div>
          )}

          {error && (
            <div role="alert" className="mb-5 rounded-xl border border-red-200 bg-red-50 p-3.5 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200">
              {error}
            </div>
          )}

          <form onSubmit={onSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label htmlFor="al-name" className="label">
                  Full name
                </label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
                  <input id="al-name" className="input !pl-10" value={form.name} onChange={set('name')} autoComplete="name" required />
                </div>
              </div>
            )}
            <div>
              <label htmlFor="al-email" className="label">
                Email
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
                <input id="al-email" type="email" className="input !pl-10" value={form.email} onChange={set('email')} autoComplete="email" required />
              </div>
            </div>
            <div>
              <label htmlFor="al-password" className="label">
                Password
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
                <input
                  id="al-password"
                  type={showPw ? 'text' : 'password'}
                  className="input !px-10"
                  value={form.password}
                  onChange={set('password')}
                  autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                  minLength={6}
                  required
                />
                <button type="button" onClick={() => setShowPw((s) => !s)} className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600" aria-label={showPw ? 'Hide password' : 'Show password'}>
                  {showPw ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={busy} className="btn btn-primary w-full !py-3">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} {mode === 'signin' ? 'Sign in' : 'Create account'}
            </button>
          </form>

          <p className="mt-5 text-center text-sm text-slate-500 dark:text-slate-400">
            {mode === 'signin' ? 'Need a reader account?' : 'Already have an account?'}{' '}
            <button
              type="button"
              className="font-semibold text-brand-600 hover:underline"
              onClick={() => {
                setMode(mode === 'signin' ? 'signup' : 'signin');
                setError('');
              }}
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
        <p className="mt-5 text-center text-sm text-brand-100">
          <Link to="/" className="hover:underline">
            ← Back to website
          </Link>
        </p>
      </div>
    </div>
  );
}
