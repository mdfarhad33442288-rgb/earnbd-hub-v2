import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Database, Eye, FileText, FolderOpen, Inbox, Mail, PenLine, PlusCircle, Users } from 'lucide-react';
import { AdminPageHeader, BarChart, StatCard, StatusBadge } from '../../components/admin/AdminUI';
import { TableSkeleton } from '../../components/ui/Skeletons';
import { ErrorState } from '../../components/ui/ErrorState';
import ConfirmDialog from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { useAsync } from '../../hooks/useAsync';
import {
  getDailyViews,
  isDemo,
  listCategories,
  listMessages,
  listPosts,
  listSubscribers,
  listUsers,
  seedSampleData,
} from '../../services/db';
import { formatDate, formatNumber } from '../../lib/utils';

export default function AdminDashboard() {
  const { toast } = useToast();
  const [seedOpen, setSeedOpen] = useState(false);
  const [seeding, setSeeding] = useState(false);

  const { data, loading, error, reload } = useAsync(async () => {
    const [posts, categories, users, subscribers, messages, daily] = await Promise.all([
      listPosts({ drafts: true }),
      listCategories(),
      listUsers(),
      listSubscribers(),
      listMessages(),
      getDailyViews(14),
    ]);
    return { posts, categories, users, subscribers, messages, daily };
  }, []);

  async function onSeed() {
    setSeeding(true);
    try {
      const r = await seedSampleData();
      toast(isDemo ? 'Demo data reset.' : `Added ${r.posts} sample posts and default categories.`);
      setSeedOpen(false);
      reload();
    } catch (err) {
      toast(err.message || 'Could not add sample data.', 'error');
    } finally {
      setSeeding(false);
    }
  }

  const actions = (
    <>
      <button type="button" className="btn btn-outline btn-sm" onClick={() => setSeedOpen(true)}>
        <Database className="h-4 w-4" /> {isDemo ? 'Reset demo data' : 'Add sample data'}
      </button>
      <Link to="/admin/posts/new" className="btn btn-primary btn-sm">
        <PlusCircle className="h-4 w-4" /> New post
      </Link>
    </>
  );

  if (error) {
    return (
      <>
        <AdminPageHeader title="Dashboard" actions={actions} />
        <ErrorState title="Could not load dashboard" message={error.message} onRetry={reload} />
      </>
    );
  }

  const posts = data?.posts || [];
  const published = posts.filter((p) => p.status === 'published');
  const totalViews = posts.reduce((s, p) => s + p.views, 0);
  const topPosts = [...posts].sort((a, b) => b.views - a.views).slice(0, 5);
  const recent = posts.slice(0, 5);

  return (
    <>
      <AdminPageHeader title="Dashboard" subtitle="A quick overview of your website." actions={actions} />

      {loading ? (
        <div className="card">
          <TableSkeleton rows={8} />
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard icon={FileText} label="Total posts" value={posts.length} hint={`${published.length} published · ${posts.length - published.length} drafts`} />
            <StatCard icon={Eye} label="Total post views" value={formatNumber(totalViews)} hint="All time" tone="green" />
            <StatCard icon={Users} label="Registered users" value={data.users.length} hint={`${data.users.filter((u) => u.role === 'admin').length} admin`} tone="violet" />
            <StatCard icon={Mail} label="Subscribers" value={data.subscribers.length} hint={`${data.messages.length} messages in inbox`} tone="amber" />
          </div>

          <div className="grid gap-6 xl:grid-cols-3">
            <section className="card p-5 xl:col-span-2">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg">Traffic – last 14 days</h2>
                  <p className="text-xs text-slate-500">{formatNumber(data.daily.reduce((s, d) => s + d.views, 0))} page views</p>
                </div>
                <Link to="/admin/analytics" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-600 hover:underline">
                  Full analytics <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <BarChart data={data.daily.map((d) => ({ label: d.date.slice(5), value: d.views }))} />
            </section>

            <section className="card p-5">
              <h2 className="mb-4 text-lg">Quick actions</h2>
              <div className="grid gap-2">
                {[
                  { to: '/admin/posts/new', icon: PenLine, label: 'Write a new post' },
                  { to: '/admin/categories', icon: FolderOpen, label: 'Manage categories' },
                  { to: '/admin/users', icon: Users, label: 'Manage users' },
                  { to: '/admin/inbox', icon: Inbox, label: 'Open inbox' },
                ].map(({ to, icon: Icon, label }) => (
                  <Link key={to} to={to} className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold transition hover:border-brand-300 hover:bg-brand-50 dark:border-slate-800 dark:hover:bg-slate-800">
                    <span className="flex items-center gap-3">
                      <Icon className="h-4 w-4 text-brand-600" /> {label}
                    </span>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </Link>
                ))}
              </div>
            </section>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <section className="card overflow-hidden">
              <div className="flex items-center justify-between p-5 pb-3">
                <h2 className="text-lg">Recent posts</h2>
                <Link to="/admin/posts" className="text-sm font-semibold text-brand-600 hover:underline">
                  View all
                </Link>
              </div>
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {recent.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 px-5 py-3">
                    <div className="min-w-0">
                      <Link to={`/admin/posts/${p.id}/edit`} className="block truncate text-sm font-semibold text-slate-900 hover:text-brand-600 dark:text-slate-100">
                        {p.title}
                      </Link>
                      <p className="text-xs text-slate-500">{formatDate(p.createdAt)}</p>
                    </div>
                    <StatusBadge status={p.status} />
                  </li>
                ))}
                {!recent.length && <li className="px-5 py-8 text-center text-sm text-slate-500">No posts yet.</li>}
              </ul>
            </section>

            <section className="card overflow-hidden">
              <div className="p-5 pb-3">
                <h2 className="text-lg">Top performing posts</h2>
              </div>
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {topPosts.map((p, i) => (
                  <li key={p.id} className="flex items-center gap-4 px-5 py-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-brand-50 text-xs font-bold text-brand-700 dark:bg-brand-500/15">{i + 1}</span>
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-900 dark:text-slate-100">{p.title}</span>
                    <span className="inline-flex shrink-0 items-center gap-1 text-sm text-slate-500">
                      <Eye className="h-4 w-4" /> {formatNumber(p.views)}
                    </span>
                  </li>
                ))}
                {!topPosts.length && <li className="px-5 py-8 text-center text-sm text-slate-500">No data yet.</li>}
              </ul>
            </section>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={seedOpen}
        busy={seeding}
        title={isDemo ? 'Reset demo data?' : 'Add sample data?'}
        message={
          isDemo
            ? 'This restores the original demo posts, categories and users and removes your demo changes.'
            : 'This adds the default categories and 11 sample posts to your Firestore database. Existing posts are kept.'
        }
        confirmLabel={isDemo ? 'Reset' : 'Add data'}
        onConfirm={onSeed}
        onCancel={() => setSeedOpen(false)}
      />
    </>
  );
}
