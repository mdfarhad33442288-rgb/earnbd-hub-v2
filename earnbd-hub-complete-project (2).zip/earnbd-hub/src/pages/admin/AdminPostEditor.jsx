import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  Bold,
  Code,
  Eye,
  EyeOff,
  Heading2,
  ImageIcon,
  Italic,
  Link2,
  List,
  ListOrdered,
  Loader2,
  Quote,
  Save,
  Send,
  Trash2,
  Upload,
} from 'lucide-react';
import { AdminPageHeader } from '../../components/admin/AdminUI';
import { ErrorState } from '../../components/ui/ErrorState';
import { useToast } from '../../components/ui/Toast';
import { useAuth } from '../../context/AuthContext';
import { getPostById, listCategories, savePost, uploadImage } from '../../services/db';
import { renderMarkdown } from '../../lib/markdown';
import { slugify } from '../../lib/utils';
import { coverFor } from '../../lib/cover';

const EMPTY = {
  title: '',
  slug: '',
  excerpt: '',
  content: '',
  coverImage: '',
  category: '',
  tags: '',
  author: 'EarnBD Editorial',
  status: 'draft',
  featured: false,
  sponsored: false,
  seoTitle: '',
  seoDescription: '',
};

function Counter({ value, max }) {
  const over = value.length > max;
  return (
    <span className={`text-xs ${over ? 'font-semibold text-amber-600' : 'text-slate-400'}`}>
      {value.length}/{max}
    </span>
  );
}

export default function AdminPostEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user } = useAuth();

  const [form, setForm] = useState({ ...EMPTY, author: user?.displayName || EMPTY.author });
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(Boolean(id));
  const [loadError, setLoadError] = useState(null);
  const [saving, setSaving] = useState('');
  const [slugTouched, setSlugTouched] = useState(Boolean(id));
  const [preview, setPreview] = useState(false);
  const [coverProgress, setCoverProgress] = useState(null);
  const [inlineProgress, setInlineProgress] = useState(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const cats = await listCategories();
        if (!alive) return;
        setCategories(cats);
        if (id) {
          const post = await getPostById(id);
          if (!alive) return;
          if (!post) throw new Error('Post not found.');
          setForm({ ...EMPTY, ...post, tags: (post.tags || []).join(', ') });
        } else {
          setForm((f) => ({ ...f, category: f.category || cats[0]?.slug || '' }));
        }
      } catch (err) {
        if (alive) setLoadError(err);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [id]);

  const set = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (key === 'title' && !slugTouched) next.slug = slugify(value);
      return next;
    });
  };

  const rendered = useMemo(() => (preview ? renderMarkdown(form.content) : null), [preview, form.content]);
  const wordCount = useMemo(() => form.content.trim().split(/\s+/).filter(Boolean).length, [form.content]);

  /** Wrap the current selection (or insert a placeholder) with markdown syntax. */
  function format(before, after = '', placeholder = 'text') {
    const el = textareaRef.current;
    const value = form.content;
    const start = el ? el.selectionStart : value.length;
    const end = el ? el.selectionEnd : value.length;
    const selected = value.slice(start, end) || placeholder;
    const next = `${value.slice(0, start)}${before}${selected}${after}${value.slice(end)}`;
    setForm((f) => ({ ...f, content: next }));
    requestAnimationFrame(() => {
      if (!el) return;
      el.focus();
      el.setSelectionRange(start + before.length, start + before.length + selected.length);
    });
  }

  async function onCoverFile(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setCoverProgress(0);
    try {
      const url = await uploadImage(file, setCoverProgress);
      setForm((f) => ({ ...f, coverImage: url }));
      toast('Cover image uploaded.');
    } catch (err) {
      toast(err.message || 'Upload failed.', 'error');
    } finally {
      setCoverProgress(null);
    }
  }

  async function onInlineFile(e) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setInlineProgress(0);
    try {
      const url = await uploadImage(file, setInlineProgress);
      format(`![`, `](${url})`, file.name.replace(/\.[^.]+$/, ''));
      toast('Image inserted into the article.');
    } catch (err) {
      toast(err.message || 'Upload failed.', 'error');
    } finally {
      setInlineProgress(null);
    }
  }

  async function save(status) {
    if (!form.title.trim()) return toast('Please enter a title.', 'error');
    if (!form.content.trim()) return toast('Please write some content.', 'error');
    if (!form.category) return toast('Please choose a category.', 'error');
    setSaving(status);
    try {
      await savePost({
        ...form,
        id,
        status,
        tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      });
      toast(status === 'published' ? 'Post published!' : 'Draft saved.');
      navigate('/admin/posts');
    } catch (err) {
      toast(err.code === 'permission-denied' ? 'Permission denied – check your Firestore rules and admin role.' : err.message || 'Could not save.', 'error');
    } finally {
      setSaving('');
    }
  }

  if (loadError) {
    return (
      <>
        <AdminPageHeader title="Edit post" />
        <ErrorState title="Could not load post" message={loadError.message} />
      </>
    );
  }
  if (loading) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-10 w-64" />
        <div className="skeleton h-96 w-full rounded-2xl" />
      </div>
    );
  }

  const toolbarBtn = 'grid h-9 w-9 place-items-center rounded-lg text-slate-600 transition hover:bg-brand-50 hover:text-brand-700 dark:text-slate-300 dark:hover:bg-slate-800';

  return (
    <>
      <AdminPageHeader
        title={id ? 'Edit post' : 'New post'}
        subtitle={id ? `Editing “${form.title}”` : 'Write and publish a new article.'}
        actions={
          <Link to="/admin/posts" className="btn btn-ghost btn-sm">
            <ArrowLeft className="h-4 w-4" /> Back to posts
          </Link>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[1fr_22rem]">
        {/* ───────── main column ───────── */}
        <div className="space-y-5">
          <div className="card space-y-5 p-5">
            <div>
              <label htmlFor="pe-title" className="label">
                Title
              </label>
              <input id="pe-title" className="input !text-lg !font-semibold" value={form.title} onChange={set('title')} placeholder="Post title" />
            </div>
            <div>
              <label htmlFor="pe-slug" className="label">
                URL slug
              </label>
              <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 pl-3 text-sm text-slate-500 focus-within:border-brand-500 focus-within:ring-2 focus-within:ring-brand-500/20 dark:border-slate-700 dark:bg-slate-900">
                <span className="shrink-0">/blog/</span>
                <input
                  id="pe-slug"
                  value={form.slug}
                  onChange={(e) => {
                    setSlugTouched(true);
                    setForm((f) => ({ ...f, slug: slugify(e.target.value) }));
                  }}
                  className="w-full bg-transparent px-1 py-2.5 text-slate-900 outline-none dark:text-slate-100"
                  placeholder="auto-generated-from-title"
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="pe-excerpt" className="label">
                  Excerpt
                </label>
                <Counter value={form.excerpt} max={160} />
              </div>
              <textarea id="pe-excerpt" rows={2} className="input resize-y" value={form.excerpt} onChange={set('excerpt')} placeholder="A short summary shown on cards and in search results" />
            </div>
          </div>

          <div className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 bg-slate-50 px-3 py-2 dark:border-slate-800 dark:bg-slate-900/60">
              <div className="flex flex-wrap items-center gap-0.5" role="toolbar" aria-label="Formatting">
                <button type="button" className={toolbarBtn} onClick={() => format('## ', '', 'Heading')} aria-label="Heading" title="Heading">
                  <Heading2 className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('**', '**', 'bold text')} aria-label="Bold" title="Bold">
                  <Bold className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('*', '*', 'italic text')} aria-label="Italic" title="Italic">
                  <Italic className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('[', '](https://)', 'link text')} aria-label="Link" title="Link">
                  <Link2 className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('- ', '', 'List item')} aria-label="Bulleted list" title="Bulleted list">
                  <List className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('1. ', '', 'List item')} aria-label="Numbered list" title="Numbered list">
                  <ListOrdered className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('> ', '', 'Quote')} aria-label="Quote" title="Quote">
                  <Quote className="h-4 w-4" />
                </button>
                <button type="button" className={toolbarBtn} onClick={() => format('`', '`', 'code')} aria-label="Code" title="Code">
                  <Code className="h-4 w-4" />
                </button>
                <label className={`${toolbarBtn} cursor-pointer`} title="Insert image" aria-label="Insert image">
                  {inlineProgress === null ? <ImageIcon className="h-4 w-4" /> : <Loader2 className="h-4 w-4 animate-spin" />}
                  <input type="file" accept="image/*" className="sr-only" onChange={onInlineFile} />
                </label>
              </div>
              <button type="button" onClick={() => setPreview((p) => !p)} className="btn btn-outline btn-sm">
                {preview ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />} {preview ? 'Edit' : 'Preview'}
              </button>
            </div>

            {preview ? (
              <div className="prose-article min-h-[26rem] p-6">
                {form.content.trim() ? <div dangerouslySetInnerHTML={{ __html: rendered.html }} /> : <p className="text-slate-400">Nothing to preview yet.</p>}
              </div>
            ) : (
              <textarea
                ref={textareaRef}
                value={form.content}
                onChange={set('content')}
                rows={22}
                aria-label="Article content (Markdown)"
                placeholder={'Write your article in Markdown…\n\n## A heading\nSome **bold** text, a [link](https://example.com) and a list:\n- First\n- Second'}
                className="block min-h-[26rem] w-full resize-y bg-transparent p-5 font-mono text-sm leading-7 text-slate-900 outline-none placeholder:text-slate-400 dark:text-slate-100"
              />
            )}
            <div className="flex justify-between border-t border-slate-200 px-4 py-2 text-xs text-slate-400 dark:border-slate-800">
              <span>Markdown supported</span>
              <span>
                {wordCount} words · ~{Math.max(1, Math.round(wordCount / 200))} min read
              </span>
            </div>
          </div>

          <div className="card space-y-4 p-5">
            <h2 className="text-base">SEO settings</h2>
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="pe-seot" className="label">
                  SEO title
                </label>
                <Counter value={form.seoTitle || form.title} max={60} />
              </div>
              <input id="pe-seot" className="input" value={form.seoTitle} onChange={set('seoTitle')} placeholder={form.title || 'Defaults to the post title'} />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label htmlFor="pe-seod" className="label">
                  Meta description
                </label>
                <Counter value={form.seoDescription || form.excerpt} max={160} />
              </div>
              <textarea id="pe-seod" rows={2} className="input resize-y" value={form.seoDescription} onChange={set('seoDescription')} placeholder={form.excerpt || 'Defaults to the excerpt'} />
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-950">
              <p className="text-xs text-slate-400">Search preview</p>
              <p className="mt-1 truncate text-lg text-[#1a0dab] dark:text-sky-400">{form.seoTitle || form.title || 'Post title'}</p>
              <p className="truncate text-xs text-emerald-700 dark:text-emerald-400">/blog/{form.slug || 'your-post'}</p>
              <p className="mt-0.5 line-clamp-2 text-sm text-slate-600 dark:text-slate-400">{form.seoDescription || form.excerpt || 'Your meta description will appear here.'}</p>
            </div>
          </div>
        </div>

        {/* ───────── side column ───────── */}
        <aside className="space-y-5 xl:sticky xl:top-24 xl:self-start">
          <div className="card space-y-4 p-5">
            <h2 className="text-base">Publish</h2>
            <p className="text-sm text-slate-500">
              Status:{' '}
              <strong className={form.status === 'published' ? 'text-emerald-600' : 'text-slate-700 dark:text-slate-200'}>
                {form.status === 'published' ? 'Published' : 'Draft'}
              </strong>
            </p>
            <div className="grid gap-2">
              <button type="button" className="btn btn-primary" disabled={Boolean(saving)} onClick={() => save('published')}>
                {saving === 'published' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {form.status === 'published' ? 'Update' : 'Publish'}
              </button>
              <button type="button" className="btn btn-outline" disabled={Boolean(saving)} onClick={() => save('draft')}>
                {saving === 'draft' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {form.status === 'published' ? 'Unpublish (save as draft)' : 'Save draft'}
              </button>
            </div>
          </div>

          <div className="card space-y-4 p-5">
            <div>
              <label htmlFor="pe-cat" className="label">
                Category
              </label>
              <select id="pe-cat" className="input" value={form.category} onChange={set('category')}>
                <option value="">Select a category…</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="pe-tags" className="label">
                Tags
              </label>
              <input id="pe-tags" className="input" value={form.tags} onChange={set('tags')} placeholder="ai, freelancing, tips" />
              <p className="mt-1 text-xs text-slate-400">Separate tags with commas.</p>
            </div>
            <div>
              <label htmlFor="pe-author" className="label">
                Author
              </label>
              <input id="pe-author" className="input" value={form.author} onChange={set('author')} />
            </div>
            <label className="flex cursor-pointer items-center gap-3 text-sm font-medium">
              <input type="checkbox" checked={form.featured} onChange={set('featured')} className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500" />
              Featured post (shown on the home page)
            </label>
            <label className="flex cursor-pointer items-center gap-3 text-sm font-medium">
              <input type="checkbox" checked={form.sponsored} onChange={set('sponsored')} className="h-4 w-4 rounded border-slate-300 text-amber-500 focus:ring-amber-400" />
              Sponsored content (adds a disclosure label)
            </label>
          </div>

          <div className="card p-5">
            <h2 className="mb-3 text-base">Cover image</h2>
            <div className="aspect-[16/9] overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-700 dark:bg-slate-800">
              <img src={form.coverImage || coverFor(form.slug || form.title || 'new')} alt="Cover preview" className="h-full w-full object-cover" />
            </div>
            {coverProgress !== null && (
              <div className="mt-3" role="progressbar" aria-valuenow={coverProgress} aria-valuemin={0} aria-valuemax={100}>
                <div className="h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                  <div className="h-full rounded-full bg-brand-600 transition-all" style={{ width: `${coverProgress}%` }} />
                </div>
                <p className="mt-1 text-xs text-slate-500">Uploading… {coverProgress}%</p>
              </div>
            )}
            <div className="mt-3 flex gap-2">
              <label className="btn btn-outline btn-sm flex-1 cursor-pointer">
                <Upload className="h-4 w-4" /> {form.coverImage ? 'Replace' : 'Upload'}
                <input type="file" accept="image/*" className="sr-only" onChange={onCoverFile} />
              </label>
              {form.coverImage && (
                <button type="button" className="btn btn-ghost btn-sm text-red-600" onClick={() => setForm((f) => ({ ...f, coverImage: '' }))}>
                  <Trash2 className="h-4 w-4" /> Remove
                </button>
              )}
            </div>
            <p className="mt-2 text-xs text-slate-400">Recommended 1200×675 px. Max 5 MB. Without an image, a branded cover is generated automatically.</p>
          </div>
        </aside>
      </div>
    </>
  );
}
