import { Link } from 'react-router-dom';
import { ArrowRight, Flame } from 'lucide-react';
import Seo, { websiteSchema } from '../components/ui/Seo';
import Hero from '../components/ui/Hero';
import Reveal from '../components/ui/Reveal';
import PostCard from '../components/ui/PostCard';
import PostGrid from '../components/ui/PostGrid';
import Sidebar from '../components/ui/Sidebar';
import Newsletter from '../components/ui/Newsletter';
import AffiliateSection from '../components/ui/AffiliateSection';
import SponsoredSection from '../components/ui/SponsoredSection';
import CategoryIcon from '../components/ui/CategoryIcon';
import { PostCardSkeleton } from '../components/ui/Skeletons';
import { ErrorState } from '../components/ui/ErrorState';
import AdSlot from '../components/ads/AdSlot';
import { useData } from '../context/DataContext';
import { categoryPath } from '../config/site';

function SectionHead({ eyebrow, title, to, cta = 'View all' }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <p className="section-eyebrow">{eyebrow}</p>
        <h2 className="mt-1 text-2xl sm:text-3xl">{title}</h2>
      </div>
      {to && (
        <Link to={to} className="hidden items-center gap-1 text-sm font-semibold text-brand-600 hover:gap-2 dark:text-brand-400 sm:inline-flex">
          {cta} <ArrowRight className="h-4 w-4 transition-all" />
        </Link>
      )}
    </div>
  );
}

export default function Home() {
  const { posts, featured, popular, categories, loading, error, refresh } = useData();

  // Featured posts, topped up with the newest posts if fewer than 3 are flagged.
  const featuredList = [...featured, ...posts.filter((p) => !p.featured)].slice(0, 3);
  const [lead, ...picks] = featuredList;
  const latest = posts.slice(0, 6);
  const trending = popular.slice(0, 3);

  return (
    <>
      <Seo path="/" jsonLd={websiteSchema()} />
      <Hero />

      <div className="container-page space-y-16 pt-6 sm:space-y-20">
        {/* Categories */}
        <section aria-labelledby="cat-heading">
          <SectionHead eyebrow="Explore topics" title="Pick what you want to learn" to="/categories" cta="All categories" />
          <h2 id="cat-heading" className="sr-only">
            Categories
          </h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {categories.slice(0, 5).map((c, i) => (
              <Reveal key={c.id} delay={i * 70}>
                <Link to={categoryPath(c.slug)} className="card card-hover group flex h-full flex-col items-start p-5">
                  <span className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 transition group-hover:bg-brand-600 group-hover:text-white dark:bg-brand-500/15">
                    <CategoryIcon name={c.icon} className="h-6 w-6" />
                  </span>
                  <h3 className="text-base">{c.name}</h3>
                  <p className="mt-1 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">{c.description}</p>
                  <span className="mt-3 text-xs font-semibold text-brand-600 dark:text-brand-400">
                    {posts.filter((p) => p.category === c.slug).length} articles →
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </section>

        <AdSlot slot="header" className="!my-0" />

        {/* Featured */}
        <section aria-labelledby="featured-heading">
          <SectionHead eyebrow="Editor's choice" title="Featured posts" to="/blog" />
          <h2 id="featured-heading" className="sr-only">
            Featured posts
          </h2>
          {error ? (
            <ErrorState onRetry={refresh} />
          ) : loading ? (
            <div className="grid gap-6 lg:grid-cols-2">
              <div className="skeleton min-h-[22rem] rounded-3xl" />
              <div className="grid gap-6">
                <PostCardSkeleton />
              </div>
            </div>
          ) : lead ? (
            <div className="grid gap-6 lg:grid-cols-5">
              <div className="lg:col-span-3">
                <PostCard post={lead} variant="featured" priority />
              </div>
              <div className="card flex flex-col gap-5 p-5 lg:col-span-2">
                <h3 className="flex items-center gap-2 text-base">
                  <Flame className="h-5 w-5 text-orange-500" /> Trending now
                </h3>
                {[...picks, ...trending.filter((t) => t.id !== lead.id && !picks.some((p) => p.id === t.id))]
                  .slice(0, 4)
                  .map((p) => (
                    <PostCard key={p.id} post={p} variant="compact" />
                  ))}
              </div>
            </div>
          ) : null}
        </section>

        {/* Latest + sidebar */}
        <section aria-labelledby="latest-heading">
          <SectionHead eyebrow="Fresh from the blog" title="Latest posts" to="/blog" />
          <h2 id="latest-heading" className="sr-only">
            Latest posts
          </h2>
          <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
            <div>
              <PostGrid posts={latest} loading={loading} error={error} onRetry={refresh} columns="sm:grid-cols-2" adEvery={4} />
              <div className="mt-8 text-center">
                <Link to="/blog" className="btn btn-outline">
                  Browse all articles <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
            <Sidebar />
          </div>
        </section>

        <Reveal>
          <AffiliateSection />
        </Reveal>

        <Reveal>
          <SponsoredSection />
        </Reveal>

        <Reveal>
          <Newsletter variant="band" source="home" />
        </Reveal>
      </div>
    </>
  );
}
