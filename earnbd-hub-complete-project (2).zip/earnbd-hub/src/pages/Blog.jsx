import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Newspaper } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import PostGrid from '../components/ui/PostGrid';
import Pagination from '../components/ui/Pagination';
import Sidebar from '../components/ui/Sidebar';
import { useData } from '../context/DataContext';
import { usePagination } from '../hooks/usePagination';
import { SITE } from '../config/site';

export default function Blog() {
  const { posts, categories, loading, error, refresh } = useData();
  const [params, setParams] = useSearchParams();
  const activeCat = params.get('category') || '';

  const filtered = useMemo(() => (activeCat ? posts.filter((p) => p.category === activeCat) : posts), [posts, activeCat]);
  const { page, totalPages, pageItems, setPage } = usePagination(filtered, SITE.postsPerPage);

  function chooseCategory(slug) {
    const next = new URLSearchParams();
    if (slug) next.set('category', slug);
    setParams(next);
  }

  const chip = (active) =>
    `rounded-full border px-4 py-1.5 text-sm font-semibold transition ${
      active
        ? 'border-brand-600 bg-brand-600 text-white shadow-sm'
        : 'border-slate-200 bg-white text-slate-600 hover:border-brand-300 hover:text-brand-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
    }`;

  return (
    <>
      <Seo
        title={page > 1 ? `Blog – Page ${page}` : 'Blog – Latest Guides & Articles'}
        description="Browse the latest guides on AI tools, online income, freelancing, job circulars and education."
        path="/blog"
      />
      <PageHeader
        eyebrow="The EarnBD blog"
        title="Latest guides & articles"
        subtitle="Practical tutorials and honest advice to help you learn, earn and grow."
        crumbs={[{ label: 'Blog' }]}
        icon={<Newspaper className="h-7 w-7" />}
      />

      <div className="container-page py-10">
        <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter by category">
          <button type="button" className={chip(!activeCat)} onClick={() => chooseCategory('')}>
            All
          </button>
          {categories.map((c) => (
            <button key={c.id} type="button" className={chip(activeCat === c.slug)} onClick={() => chooseCategory(c.slug)}>
              {c.name}
            </button>
          ))}
        </div>

        <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
          <div>
            <PostGrid
              posts={pageItems}
              loading={loading}
              error={error}
              onRetry={refresh}
              columns="sm:grid-cols-2"
              adEvery={4}
              skeletonCount={6}
            />
            {!loading && !error && <Pagination page={page} totalPages={totalPages} onChange={setPage} className="mt-10" />}
          </div>
          <Sidebar />
        </div>
      </div>
    </>
  );
}
