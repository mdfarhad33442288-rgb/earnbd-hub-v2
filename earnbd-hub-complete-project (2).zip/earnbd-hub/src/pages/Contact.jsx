import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, Clock, Loader2, Mail, MessageSquare, Send } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import { SITE } from '../config/site';
import { sendMessage } from '../services/db';
import { absoluteUrl } from '../lib/utils';

export default function Contact() {
  const [params] = useSearchParams();
  const [form, setForm] = useState({ name: '', email: '', subject: params.get('subject') || '', message: '', website: '' });
  const [status, setStatus] = useState({ state: 'idle', error: '' });

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  async function onSubmit(e) {
    e.preventDefault();
    if (form.website) return; // honeypot – bots fill this hidden field
    setStatus({ state: 'loading', error: '' });
    try {
      await sendMessage(form);
      setStatus({ state: 'success', error: '' });
      setForm({ name: '', email: '', subject: '', message: '', website: '' });
    } catch (err) {
      setStatus({ state: 'error', error: err.message || 'Could not send your message. Please try again.' });
    }
  }

  return (
    <>
      <Seo
        title="Contact Us"
        description={`Get in touch with the ${SITE.name} team for questions, feedback, guest posts or advertising enquiries.`}
        path="/contact"
        jsonLd={{ '@context': 'https://schema.org', '@type': 'ContactPage', name: 'Contact', url: absoluteUrl('/contact') }}
      />
      <PageHeader
        eyebrow="Contact"
        title="We’d love to hear from you"
        subtitle="Questions, feedback, guest posts or advertising enquiries – send us a message."
        crumbs={[{ label: 'Contact' }]}
        icon={<MessageSquare className="h-7 w-7" />}
      />

      <div className="container-page grid max-w-5xl gap-8 py-12 lg:grid-cols-[1fr_20rem]">
        <form onSubmit={onSubmit} className="card space-y-5 p-6 sm:p-8" noValidate>
          {status.state === 'success' && (
            <div role="status" className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" /> Thank you! Your message has been sent. We’ll reply as soon as we can.
            </div>
          )}
          {status.state === 'error' && (
            <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-200">
              {status.error}
            </div>
          )}

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="c-name" className="label">
                Your name
              </label>
              <input id="c-name" className="input" value={form.name} onChange={set('name')} autoComplete="name" required maxLength={120} />
            </div>
            <div>
              <label htmlFor="c-email" className="label">
                Email address
              </label>
              <input id="c-email" type="email" className="input" value={form.email} onChange={set('email')} autoComplete="email" required maxLength={254} />
            </div>
          </div>
          <div>
            <label htmlFor="c-subject" className="label">
              Subject
            </label>
            <input id="c-subject" className="input" value={form.subject} onChange={set('subject')} required maxLength={200} />
          </div>
          <div>
            <label htmlFor="c-message" className="label">
              Message
            </label>
            <textarea id="c-message" rows={6} className="input resize-y" value={form.message} onChange={set('message')} required maxLength={5000} />
          </div>

          {/* Honeypot: hidden from people, visible to bots */}
          <div className="absolute -left-[9999px]" aria-hidden="true">
            <label htmlFor="c-website">Website</label>
            <input id="c-website" tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} />
          </div>

          <button type="submit" className="btn btn-primary w-full sm:w-auto" disabled={status.state === 'loading'}>
            {status.state === 'loading' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Send message
          </button>
        </form>

        <aside className="space-y-4">
          <div className="card flex items-start gap-4 p-5">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15">
              <Mail className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="font-bold text-slate-900 dark:text-white">Email us</p>
              <a href={`mailto:${SITE.email}`} className="break-all text-sm text-brand-600 hover:underline">
                {SITE.email}
              </a>
            </div>
          </div>
          <div className="card flex items-start gap-4 p-5">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15">
              <Clock className="h-5 w-5" />
            </span>
            <div>
              <p className="font-bold text-slate-900 dark:text-white">Response time</p>
              <p className="text-sm text-slate-600 dark:text-slate-400">We usually reply within 2 business days.</p>
            </div>
          </div>
          <div className="card p-5 text-sm text-slate-600 dark:text-slate-400">
            <p className="mb-1 font-bold text-slate-900 dark:text-white">Advertising & sponsorships</p>
            Want to reach our readers? Choose “Sponsored content” as the subject and tell us about your product or service.
          </div>
        </aside>
      </div>
    </>
  );
}
