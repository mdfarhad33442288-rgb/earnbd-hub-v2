import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, Home, Search } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PostCard from '../components/ui/PostCard';
import { useData } from '../context/DataContext';

/** 404 page – also rendered when a post or category slug does not exist. */
export default function NotFound() {
  const [q, setQ] = useState('');
  const navigate = useNavigate();
  const { popular } = useData();

  function onSubmit(e) {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <>
      <Seo title="Page not found (404)" description="The page you are looking for could not be found." noindex />
      <section className="relative overflow-hidden bg-gradient-to-b from-brand-50 to-white py-16 dark:from-slate-900 dark:to-slate-950 sm:py-24">
        <div className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-brand-200/50 blur-3xl dark:bg-brand-600/20" />
        <div className="container-page relative text-center">
          <p className="gradient-text animate-fade-up text-8xl font-black tracking-tighter sm:text-9xl">404</p>
          <h1 className="mt-4 text-3xl sm:text-4xl">Page not found</h1>
          <p className="mx-auto mt-3 max-w-md text-slate-600 dark:text-slate-400">
            Sorry, we couldn’t find the page you were looking for. It may have been moved or deleted.
          </p>

          <form onSubmit={onSubmit} role="search" className="mx-auto mt-8 flex max-w-md gap-2">
            <label htmlFor="nf-search" className="sr-only">
              Search the site
            </label>
            <input id="nf-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search for something else…" className="input" />
            <button type="submit" className="btn btn-primary" aria-label="Search">
              <Search className="h-4 w-4" />
            </button>
          </form>

          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/" className="btn btn-primary">
              <Home className="h-4 w-4" /> Back to home
            </Link>
            <Link to="/blog" className="btn btn-outline">
              <Compass className="h-4 w-4" /> Browse articles
            </Link>
          </div>
        </div>
      </section>

      {popular.length > 0 && (
        <div className="container-page py-12">
          <h2 className="mb-5 text-xl">You might like these</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {popular.slice(0, 3).map((p) => (
              <PostCard key={p.id} post={p} />
            ))}
          </div>
        </div>
      )}
    </>
  );
}
