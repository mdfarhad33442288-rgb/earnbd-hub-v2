import { Fragment, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Calendar, Clock, Eye, ListTree, Megaphone, Tag, UserRound } from 'lucide-react';
import Seo from '../components/ui/Seo';
import Breadcrumb from '../components/ui/Breadcrumb';
import LazyImage from '../components/ui/LazyImage';
import ShareButtons from '../components/ui/ShareButtons';
import PostCard from '../components/ui/PostCard';
import Sidebar from '../components/ui/Sidebar';
import Newsletter from '../components/ui/Newsletter';
import AffiliateSection from '../components/ui/AffiliateSection';
import { ArticleSkeleton } from '../components/ui/Skeletons';
import { ErrorState } from '../components/ui/ErrorState';
import AdSlot from '../components/ads/AdSlot';
import NotFound from './NotFound';
import { useData } from '../context/DataContext';
import { trackPostView } from '../services/db';
import { renderMarkdown } from '../lib/markdown';
import { postCover } from '../lib/cover';
import { absoluteUrl, formatDate, formatNumber, stripMarkdown, truncate } from '../lib/utils';
import { SITE, categoryPath } from '../config/site';

function ReadingProgress() {
  const [pct, setPct] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setPct(h > 0 ? Math.min(100, (window.scrollY / h) * 100) : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <div className="fixed inset-x-0 top-0 z-[60] h-1 bg-transparent" aria-hidden="true">
      <div className="h-full bg-gradient-to-r from-brand-500 to-sky-400 transition-[width] duration-100" style={{ width: `${pct}%` }} />
    </div>
  );
}

function relatedPosts(post, all, limit = 3) {
  const tags = new Set(post.tags || []);
  return all
    .filter((p) => p.id !== post.id)
    .map((p) => ({
      p,
      score: (p.category === post.category ? 3 : 0) + (p.tags || []).filter((t) => tags.has(t)).length * 2,
    }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || b.p.createdAt - a.p.createdAt)
    .slice(0, limit)
    .map((x) => x.p);
}

export default function SinglePost() {
  const { slug } = useParams();
  const { posts, loading, error, refresh, getCategory } = useData();

  const post = useMemo(() => posts.find((p) => p.slug === slug), [posts, slug]);
  const rendered = useMemo(() => renderMarkdown(post?.content || ''), [post?.content]);
  const related = useMemo(() => {
    if (!post) return [];
    const r = relatedPosts(post, posts);
    return r.length ? r : posts.filter((p) => p.id !== post.id).slice(0, 3);
  }, [post, posts]);

  useEffect(() => {
    if (post?.id) trackPostView(post.id);
  }, [post?.id]);

  if (error) {
    return (
      <div className="container-page py-16">
        <ErrorState onRetry={refresh} />
      </div>
    );
  }
  if (loading) {
    return (
      <div className="container-page py-10">
        <div className="max-w-3xl">
          <ArticleSkeleton />
        </div>
      </div>
    );
  }
  if (!post) return <NotFound />;

  const category = getCategory(post.category);
  const path = `/blog/${post.slug}`;
  const description = post.seoDescription || post.excerpt || truncate(stripMarkdown(post.content), 160);
  const title = post.seoTitle || post.title;
  const cover = postCover(post);
  const schemaImage = cover.startsWith('data:') ? absoluteUrl('/og-default.png') : cover;
  const isOrg = !post.author || post.author === 'EarnBD Editorial';

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: truncate(post.title, 110),
    description,
    image: [schemaImage],
    datePublished: new Date(post.createdAt).toISOString(),
    dateModified: new Date(post.updatedAt || post.createdAt).toISOString(),
    author: { '@type': isOrg ? 'Organization' : 'Person', name: post.author || SITE.name },
    publisher: {
      '@type': 'Organization',
      name: SITE.name,
      logo: { '@type': 'ImageObject', url: absoluteUrl('/icon-512.png') },
    },
    mainEntityOfPage: { '@type': 'WebPage', '@id': absoluteUrl(path) },
    articleSection: category.name,
    keywords: (post.tags || []).join(', '),
    wordCount: stripMarkdown(post.content).split(/\s+/).filter(Boolean).length,
  };

  // Interleave in-article ads between content blocks (after the 3rd, and after the 9th on long posts).
  const adAfter = new Set([2]);
  if (rendered.blocks.length > 12) adAfter.add(9);

  return (
    <>
      <Seo
        title={title}
        description={description}
        path={path}
        image={post.coverImage}
        type="article"
        keywords={post.tags}
        article={{
          publishedTime: new Date(post.createdAt).toISOString(),
          modifiedTime: new Date(post.updatedAt || post.createdAt).toISOString(),
          section: category.name,
          tags: post.tags,
        }}
        jsonLd={articleSchema}
      />
      <ReadingProgress />

      <div className="container-page py-8 sm:py-10">
        <Breadcrumb
          className="mb-6"
          items={[
            { label: 'Blog', to: '/blog' },
            { label: category.name, to: categoryPath(post.category) },
            { label: post.title },
          ]}
        />

        <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
          <article className="min-w-0">
            <header className="animate-fade-up">
              <div className="flex flex-wrap items-center gap-2">
                <Link to={categoryPath(post.category)} className="badge hover:bg-brand-100">
                  {category.name}
                </Link>
                {post.sponsored && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-800">
                    <Megaphone className="h-3 w-3" /> Sponsored
                  </span>
                )}
              </div>
              <h1 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl lg:text-[2.75rem]">{post.title}</h1>
              {post.excerpt && <p className="mt-4 text-lg text-slate-600 dark:text-slate-400">{post.excerpt}</p>}
              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-slate-500 dark:text-slate-400">
                <span className="inline-flex items-center gap-1.5">
                  <UserRound className="h-4 w-4" /> {post.author || SITE.name}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  <time dateTime={new Date(post.createdAt).toISOString()}>{formatDate(post.createdAt)}</time>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-4 w-4" /> {post.readingTime} min read
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Eye className="h-4 w-4" /> {formatNumber(post.views)} views
                </span>
              </div>
            </header>

            <figure className="mt-7 aspect-[16/9] overflow-hidden rounded-3xl shadow-soft">
              <LazyImage src={cover} alt={post.title} priority fallbackSeed={post.slug} />
            </figure>

            <ShareButtons title={post.title} path={path} className="mt-6" />

            {post.sponsored && (
              <p className="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200">
                <strong>Disclosure:</strong> This is a sponsored article. EarnBD Hub may receive compensation from the featured partner.
              </p>
            )}

            <AdSlot slot="inArticle" />

            {rendered.headings.length >= 3 && (
              <nav aria-label="Table of contents" className="card my-6 p-5">
                <p className="mb-3 flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
                  <ListTree className="h-4 w-4 text-brand-600" /> In this article
                </p>
                <ol className="space-y-1.5 text-sm">
                  {rendered.headings.map((h) => (
                    <li key={h.id} className={h.level === 3 ? 'ml-4' : ''}>
                      <a href={`#${h.id}`} className="text-slate-600 transition hover:text-brand-600 dark:text-slate-400 dark:hover:text-brand-400">
                        {h.text}
                      </a>
                    </li>
                  ))}
                </ol>
              </nav>
            )}

            <div className="prose-article">
              {rendered.blocks.map((html, i) => (
                <Fragment key={i}>
                  {/* Content is escaped by lib/markdown.js, which only emits a whitelist of tags. */}
                  <div dangerouslySetInnerHTML={{ __html: html }} />
                  {adAfter.has(i) && <AdSlot slot="inArticle" />}
                </Fragment>
              ))}
            </div>

            {post.tags?.length > 0 && (
              <div className="mt-10 flex flex-wrap items-center gap-2">
                <Tag className="h-4 w-4 text-slate-400" />
                {post.tags.map((t) => (
                  <Link key={t} to={`/search?q=${encodeURIComponent(t)}`} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-600 transition hover:bg-brand-50 hover:text-brand-700 dark:bg-slate-800 dark:text-slate-300">
                    #{t}
                  </Link>
                ))}
              </div>
            )}

            <div className="card mt-8 flex flex-col items-start gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Found this helpful? Share it with a friend.</p>
              <ShareButtons title={post.title} path={path} />
            </div>

            <div className="card mt-8 flex items-start gap-4 p-5">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-lg font-bold text-white">
                {(post.author || 'E').charAt(0).toUpperCase()}
              </span>
              <div>
                <p className="text-xs font-bold uppercase tracking-widest text-slate-400">Written by</p>
                <p className="font-bold text-slate-900 dark:text-white">{post.author || SITE.name}</p>
                <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                  Sharing practical guides on AI tools, online income, freelancing, jobs and education.{' '}
                  <Link to="/about" className="font-semibold text-brand-600 hover:underline">
                    About us
                  </Link>
                </p>
              </div>
            </div>

            <AdSlot slot="footer" />
            <AffiliateSection compact />

            {related.length > 0 && (
              <section aria-labelledby="related-heading" className="mt-12">
                <h2 id="related-heading" className="mb-5 text-2xl">
                  Related posts
                </h2>
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {related.map((p) => (
                    <PostCard key={p.id} post={p} />
                  ))}
                </div>
              </section>
            )}

            <div className="mt-12">
              <Newsletter variant="band" source="post" />
            </div>
          </article>

          <Sidebar excludeId={post.id} showNewsletter={false} />
        </div>
      </div>
    </>
  );
}
