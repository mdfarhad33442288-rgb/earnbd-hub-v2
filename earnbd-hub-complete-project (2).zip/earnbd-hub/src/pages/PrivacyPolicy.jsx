import LegalPage from '../components/ui/LegalPage';
import { SITE } from '../config/site';

const sections = [
  {
    title: 'Information we collect',
    body: [
      'We collect only the information needed to run and improve the website:',
      [
        'Information you give us – your name, email address and message when you use the contact form, or your email address when you subscribe to the newsletter.',
        'Account information – if you create an account, your email address, display name and account role.',
        'Usage data – anonymous page-view counts and technical data such as browser type, device type and approximate location, collected through analytics tools.',
      ],
    ],
  },
  {
    title: 'How we use your information',
    body: [
      'We use your information to respond to your enquiries, send newsletters you have asked for, keep the site secure, understand which content is useful and improve our service. We do not sell your personal information.',
    ],
  },
  {
    title: 'Cookies and similar technologies',
    body: [
      'We and our partners use cookies and similar technologies to remember your preferences (such as dark mode), measure traffic and show advertising. You can control cookies through your browser settings and through the consent banner on this site.',
    ],
  },
  {
    title: 'Google AdSense and advertising',
    body: [
      'We use Google AdSense to display ads. Google and its partners may use cookies to serve ads based on your visits to this and other websites. You can opt out of personalised advertising by visiting Google Ads Settings (adssettings.google.com) or aboutads.info. If you choose “non-personalised” in our consent banner, we request non-personalised ads.',
    ],
  },
  {
    title: 'Third-party services',
    body: [
      'The site is built on Google Firebase (authentication, database and file storage) and may use Google Analytics. These providers process data under their own privacy policies. Some pages contain links to external sites and affiliate links; we are not responsible for the privacy practices of those sites.',
    ],
  },
  {
    title: 'Affiliate links',
    body: [
      'Some links are affiliate links. If you click a link and make a purchase, we may earn a commission at no extra cost to you. Affiliate relationships are disclosed on the pages where they appear.',
    ],
  },
  {
    title: 'Data retention and security',
    body: [
      'We keep personal information only as long as needed for the purposes described here or as required by law. We use reasonable technical measures to protect your data, but no method of transmission or storage is completely secure.',
    ],
  },
  {
    title: 'Your rights',
    body: [
      'Depending on where you live, you may have the right to access, correct or delete your personal data, to object to or restrict certain processing, and to unsubscribe from our newsletter at any time. To exercise these rights, contact us using the details below.',
    ],
  },
  {
    title: 'Children’s privacy',
    body: ['Our website is not directed to children under 13, and we do not knowingly collect personal information from them.'],
  },
  {
    title: 'Changes to this policy',
    body: ['We may update this Privacy Policy from time to time. The “last updated” date at the top shows when it was last changed.'],
  },
  {
    title: 'Contact us',
    body: [`If you have questions about this policy, email us at ${SITE.email}.`],
  },
];

export default function PrivacyPolicy() {
  return (
    <LegalPage
      title="Privacy Policy"
      description={`How ${SITE.name} collects, uses and protects your information, including cookies and Google AdSense.`}
      path="/privacy-policy"
      updated="November 21, 2026"
      intro={`Your privacy matters to us. This policy explains what information ${SITE.name} collects when you use our website and how we use it.`}
      sections={sections}
    />
  );
}
