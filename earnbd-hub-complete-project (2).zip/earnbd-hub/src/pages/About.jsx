import { Link } from 'react-router-dom';
import { BadgeCheck, BookOpen, HeartHandshake, Info, Target } from 'lucide-react';
import Seo from '../components/ui/Seo';
import PageHeader from '../components/ui/PageHeader';
import Reveal from '../components/ui/Reveal';
import CategoryIcon from '../components/ui/CategoryIcon';
import Newsletter from '../components/ui/Newsletter';
import { DEFAULT_CATEGORIES, SITE, categoryPath } from '../config/site';
import { absoluteUrl } from '../lib/utils';

const VALUES = [
  { icon: BadgeCheck, title: 'Honest & realistic', text: 'No get-rich-quick promises. We explain what works, what it costs and how long it really takes.' },
  { icon: BookOpen, title: 'Beginner friendly', text: 'Clear, step-by-step guides written in simple language so anyone can follow along.' },
  { icon: HeartHandshake, title: 'Transparent', text: 'Ads, affiliate links and sponsored posts are always clearly labelled – our readers come first.' },
  { icon: Target, title: 'Action-focused', text: 'Every article ends with practical next steps you can start on the same day.' },
];

export default function About() {
  return (
    <>
      <Seo
        title="About Us"
        description={`Learn about ${SITE.name} – our mission, editorial approach and how we keep our guides honest and useful.`}
        path="/about"
        jsonLd={{
          '@context': 'https://schema.org',
          '@type': 'AboutPage',
          name: `About ${SITE.name}`,
          url: absoluteUrl('/about'),
        }}
      />
      <PageHeader
        eyebrow="About us"
        title={`About ${SITE.name}`}
        subtitle="We help learners, job seekers and freelancers in Bangladesh build skills and income with practical, trustworthy guides."
        crumbs={[{ label: 'About' }]}
        icon={<Info className="h-7 w-7" />}
      />

      <div className="container-page max-w-5xl space-y-16 py-12">
        <section className="grid items-center gap-8 md:grid-cols-2">
          <div>
            <p className="section-eyebrow">Our mission</p>
            <h2 className="mt-1 text-3xl">Make learning and earning online accessible to everyone</h2>
            <p className="mt-4 leading-7 text-slate-600 dark:text-slate-400">
              {SITE.name} started with a simple idea: good information should be easy to find and easy to trust. We research, test and explain
              tools, platforms and strategies in plain language, so you can spend less time searching and more time doing.
            </p>
            <p className="mt-3 leading-7 text-slate-600 dark:text-slate-400">
              Whether you are exploring AI tools, starting your freelance journey, preparing for a job circular or planning your studies, our
              goal is to give you a clear path forward.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              ['5', 'Core topics'],
              ['100%', 'Free to read'],
              ['Weekly', 'New guides'],
              ['0', 'Paid-for rankings'],
            ].map(([n, l], i) => (
              <Reveal key={l} delay={i * 80}>
                <div className="card p-5 text-center">
                  <p className="gradient-text text-3xl font-extrabold">{n}</p>
                  <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{l}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-6 text-center text-3xl">What we stand for</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            {VALUES.map(({ icon: Icon, title, text }, i) => (
              <Reveal key={title} delay={i * 80}>
                <div className="card flex h-full gap-4 p-6">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/15">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div>
                    <h3 className="text-lg">{title}</h3>
                    <p className="mt-1 text-sm leading-6 text-slate-600 dark:text-slate-400">{text}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </section>

        <section>
          <h2 className="mb-6 text-center text-3xl">What we cover</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {DEFAULT_CATEGORIES.map((c) => (
              <Link key={c.id} to={categoryPath(c.slug)} className="card card-hover flex items-start gap-3 p-5">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-600 text-white">
                  <CategoryIcon name={c.icon} className="h-5 w-5" />
                </span>
                <span>
                  <span className="block font-bold text-slate-900 dark:text-white">{c.name}</span>
                  <span className="mt-0.5 block text-xs text-slate-500 dark:text-slate-400">{c.description}</span>
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section className="card p-6 sm:p-8">
          <h2 className="text-2xl">How we make money</h2>
          <p className="mt-3 leading-7 text-slate-600 dark:text-slate-400">
            {SITE.name} is free to read. We earn revenue from display advertising (Google AdSense), affiliate links and sponsored content.
            Affiliate links and sponsored posts are always labelled. We only recommend products we believe are useful, and compensation never
            changes our honest assessment.
          </p>
          <p className="mt-3 text-sm text-slate-500 dark:text-slate-400">
            Articles are for general information only and are not professional financial, legal or career advice.
          </p>
        </section>

        <Newsletter variant="band" source="about" />
      </div>
    </>
  );
}
