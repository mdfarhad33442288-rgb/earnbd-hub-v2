/**
 * Authentication service (Firebase Auth + Firestore role profile, or a local demo session).
 * A user's role lives in Firestore: users/{uid}.role  ('admin' | 'user').
 */
import { getFirebase, isFirebaseConfigured } from '../lib/firebase';
import { DEMO_ADMIN, ensureSeed, load, save } from './demoStore';

const isDemo = !isFirebaseConfigured;
const SESSION_EVENT = 'ebd-auth';

export function authErrorMessage(err) {
  const map = {
    'auth/invalid-credential': 'Incorrect email or password.',
    'auth/invalid-email': 'Please enter a valid email address.',
    'auth/user-not-found': 'No account found with that email.',
    'auth/wrong-password': 'Incorrect email or password.',
    'auth/email-already-in-use': 'An account with this email already exists.',
    'auth/weak-password': 'Password must be at least 6 characters.',
    'auth/too-many-requests': 'Too many attempts. Please try again later.',
    'auth/network-request-failed': 'Network error. Check your connection and try again.',
    'permission-denied': 'Permission denied. Check your Firestore security rules.',
  };
  return map[err?.code] || err?.message || 'Something went wrong. Please try again.';
}

/* ───────────── demo mode ───────────── */

function demoUser() {
  const session = load('session', null);
  if (!session) return null;
  const u = load('users', []).find((x) => x.uid === session.uid);
  return u ? { uid: u.uid, email: u.email, displayName: u.displayName, role: u.role } : null;
}
const emitDemo = () => window.dispatchEvent(new Event(SESSION_EVENT));

/* ───────────── firebase mode ───────────── */

async function buildUser(fbUser, displayNameOverride) {
  const { fs, db } = await getFirebase();
  const ref = fs.doc(db, 'users', fbUser.uid);
  let snap = await fs.getDoc(ref);
  if (!snap.exists()) {
    try {
      await fs.setDoc(ref, {
        email: fbUser.email || '',
        displayName: displayNameOverride || fbUser.displayName || '',
        role: 'user',
        createdAt: Date.now(),
      });
    } catch {
      /* another tab/call may have created it first */
    }
    snap = await fs.getDoc(ref);
  }
  const data = snap.data() || {};
  return {
    uid: fbUser.uid,
    email: fbUser.email || data.email || '',
    displayName: data.displayName || fbUser.displayName || '',
    role: data.role === 'admin' ? 'admin' : 'user',
  };
}

/* ───────────── public API ───────────── */

export function onAuthChange(callback) {
  if (isDemo) {
    ensureSeed();
    callback(demoUser());
    const handler = () => callback(demoUser());
    window.addEventListener(SESSION_EVENT, handler);
    return () => window.removeEventListener(SESSION_EVENT, handler);
  }

  let unsubscribe = () => {};
  let disposed = false;
  getFirebase()
    .then(({ auth, authMod }) => {
      if (disposed) return;
      unsubscribe = authMod.onAuthStateChanged(auth, async (fbUser) => {
        if (!fbUser) {
          callback(null);
          return;
        }
        try {
          callback(await buildUser(fbUser));
        } catch (err) {
          console.error('Could not load user profile', err);
          callback({ uid: fbUser.uid, email: fbUser.email || '', displayName: fbUser.displayName || '', role: 'user' });
        }
      });
    })
    .catch((err) => {
      console.error(err);
      callback(null);
    });
  return () => {
    disposed = true;
    unsubscribe();
  };
}

export async function signIn(email, password) {
  if (isDemo) {
    ensureSeed();
    const users = load('users', []);
    const match =
      email === DEMO_ADMIN.email && password === DEMO_ADMIN.password
        ? users.find((u) => u.uid === DEMO_ADMIN.uid)
        : users.find((u) => u.email === email && u.password && u.password === password);
    if (!match) throw Object.assign(new Error('Incorrect email or password.'), { code: 'auth/invalid-credential' });
    save('session', { uid: match.uid });
    emitDemo();
    return;
  }
  const { auth, authMod } = await getFirebase();
  await authMod.signInWithEmailAndPassword(auth, email, password);
}

export async function signUp(email, password, displayName) {
  if (isDemo) {
    const users = load('users', []);
    if (users.some((u) => u.email === email)) throw Object.assign(new Error('exists'), { code: 'auth/email-already-in-use' });
    if (password.length < 6) throw Object.assign(new Error('weak'), { code: 'auth/weak-password' });
    const user = { uid: `demo-${Date.now().toString(36)}`, email, displayName, role: 'user', password, createdAt: Date.now() };
    save('users', [user, ...users]);
    save('session', { uid: user.uid });
    emitDemo();
    return;
  }
  const { auth, authMod, fs, db } = await getFirebase();
  const cred = await authMod.createUserWithEmailAndPassword(auth, email, password);
  if (displayName) {
    await authMod.updateProfile(cred.user, { displayName });
    try {
      await buildUser(cred.user, displayName);
      await fs.updateDoc(fs.doc(db, 'users', cred.user.uid), { displayName });
    } catch {
      /* non-fatal */
    }
  }
}

export async function signOut() {
  if (isDemo) {
    save('session', null);
    emitDemo();
    return;
  }
  const { auth, authMod } = await getFirebase();
  await authMod.signOut(auth);
}

export async function sendPasswordReset(email) {
  if (isDemo) return;
  const { auth, authMod } = await getFirebase();
  await authMod.sendPasswordResetEmail(auth, email);
}
