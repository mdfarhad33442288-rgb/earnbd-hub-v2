/**
 * Browser-local persistence for DEMO MODE. Falls back to in-memory storage when
 * localStorage is unavailable (private windows, blocked storage, quota errors).
 */
import { buildSeed } from '../lib/demoData';

const PREFIX = 'ebd:';
const mem = {};

export function load(key, fallback) {
  if (key in mem) return mem[key];
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (raw !== null) {
      mem[key] = JSON.parse(raw);
      return mem[key];
    }
  } catch {
    /* ignore */
  }
  return fallback;
}

export function save(key, value) {
  mem[key] = value;
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function ensureSeed() {
  if (load('seed_v', 0) >= 1) return;
  const seed = buildSeed(Date.now());
  Object.entries(seed).forEach(([key, value]) => save(key, value));
  save('seed_v', 1);
}

export function resetDemo() {
  const session = load('session', null); // keep the admin signed in
  Object.keys(mem).forEach((k) => delete mem[k]);
  try {
    Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX))
      .forEach((k) => localStorage.removeItem(k));
  } catch {
    /* ignore */
  }
  ensureSeed();
  if (session) save('session', session);
}

export const DEMO_ADMIN = {
  uid: 'demo-admin',
  email: 'admin@earnbd.demo',
  password: 'admin123',
  displayName: 'Demo Admin',
};
