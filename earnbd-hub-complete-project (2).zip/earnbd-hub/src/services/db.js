/**
 * Data layer. Every function works in two modes:
 *  - Firebase mode (Firestore + Storage) when VITE_FIREBASE_* variables are set
 *  - Demo mode (localStorage) otherwise
 * Pages never talk to Firebase directly – they only call functions from this file.
 */
import { getFirebase, isFirebaseConfigured } from '../lib/firebase';
import { buildSeed } from '../lib/demoData';
import { DEFAULT_CATEGORIES } from '../config/site';
import { dayKey, isValidEmail, readingTime, slugify, toMs } from '../lib/utils';
import { ensureSeed, load, save, resetDemo } from './demoStore';

export const isDemo = !isFirebaseConfigured;
if (isDemo) ensureSeed();

/* ───────────────────────── helpers ───────────────────────── */

let postsCache = null;
let catsCache = null;

export function invalidateCache() {
  postsCache = null;
  catsCache = null;
}

const normalizePost = (p) => ({
  ...p,
  title: p.title || 'Untitled',
  slug: p.slug || p.id,
  excerpt: p.excerpt || '',
  content: p.content || '',
  category: p.category || '',
  tags: Array.isArray(p.tags) ? p.tags : [],
  views: Number(p.views) || 0,
  status: p.status || 'draft',
  featured: Boolean(p.featured),
  sponsored: Boolean(p.sponsored),
  createdAt: toMs(p.createdAt),
  updatedAt: toMs(p.updatedAt) || toMs(p.createdAt),
  readingTime: p.readingTime || readingTime(p.content),
});

const byNewest = (a, b) => b.createdAt - a.createdAt;
const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

/* ───────────────────────── posts ───────────────────────── */

/** Published posts (cached). Pass { drafts: true } for the admin view (never cached). */
export async function listPosts({ drafts = false } = {}) {
  if (!drafts && postsCache) return postsCache;

  const run = async () => {
    let rows;
    if (isDemo) {
      rows = load('posts', []);
    } else {
      const { fs, db } = await getFirebase();
      const col = fs.collection(db, 'posts');
      const q = drafts ? col : fs.query(col, fs.where('status', '==', 'published'));
      const snap = await fs.getDocs(q);
      rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    }
    rows = rows.map(normalizePost);
    if (!drafts) rows = rows.filter((p) => p.status === 'published');
    return rows.sort(byNewest);
  };

  if (drafts) return run();
  postsCache = run().catch((err) => {
    postsCache = null;
    throw err;
  });
  return postsCache;
}

export async function getPostById(id) {
  const all = await listPosts({ drafts: true });
  return all.find((p) => p.id === id) || null;
}

export async function savePost(input) {
  const now = Date.now();
  const all = await listPosts({ drafts: true });

  let slug = slugify(input.slug || input.title) || `post-${now}`;
  const base = slug;
  let n = 2;
  while (all.some((p) => p.slug === slug && p.id !== input.id)) slug = `${base}-${n++}`;

  const data = {
    title: input.title.trim(),
    slug,
    excerpt: (input.excerpt || '').trim(),
    content: input.content || '',
    coverImage: input.coverImage || '',
    category: input.category || '',
    tags: (input.tags || []).map((t) => t.trim()).filter(Boolean),
    author: (input.author || 'EarnBD Editorial').trim(),
    status: input.status === 'published' ? 'published' : 'draft',
    featured: Boolean(input.featured),
    sponsored: Boolean(input.sponsored),
    seoTitle: (input.seoTitle || '').trim(),
    seoDescription: (input.seoDescription || '').trim(),
    readingTime: readingTime(input.content),
    updatedAt: now,
  };

  let id = input.id;
  if (isDemo) {
    const rows = load('posts', []);
    if (id) {
      save('posts', rows.map((p) => (p.id === id ? { ...p, ...data } : p)));
    } else {
      id = `demo-${newId()}`;
      save('posts', [{ id, ...data, views: 0, createdAt: now }, ...rows]);
    }
  } else {
    const { fs, db } = await getFirebase();
    if (id) {
      await fs.updateDoc(fs.doc(db, 'posts', id), data);
    } else {
      const ref = await fs.addDoc(fs.collection(db, 'posts'), { ...data, views: 0, createdAt: now });
      id = ref.id;
    }
  }
  invalidateCache();
  return { id, slug };
}

export async function deletePost(id) {
  if (isDemo) {
    save('posts', load('posts', []).filter((p) => p.id !== id));
  } else {
    const { fs, db } = await getFirebase();
    await fs.deleteDoc(fs.doc(db, 'posts', id));
  }
  invalidateCache();
}

/** Increment a post's view counter (once per post per browser session). */
export async function trackPostView(id) {
  if (!id) return;
  try {
    const key = `ebd:viewed:${id}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, '1');
  } catch {
    /* ignore */
  }
  try {
    if (isDemo) {
      save('posts', load('posts', []).map((p) => (p.id === id ? { ...p, views: (Number(p.views) || 0) + 1 } : p)));
    } else {
      const { fs, db } = await getFirebase();
      await fs.updateDoc(fs.doc(db, 'posts', id), { views: fs.increment(1) });
    }
  } catch (err) {
    console.warn('View tracking skipped:', err?.code || err);
  }
}

/* ───────────────────────── categories ───────────────────────── */

export async function listCategories() {
  if (catsCache) return catsCache;
  const run = async () => {
    if (isDemo) return load('categories', DEFAULT_CATEGORIES);
    const { fs, db } = await getFirebase();
    const snap = await fs.getDocs(fs.collection(db, 'categories'));
    const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    return rows.length ? rows.sort((a, b) => a.name.localeCompare(b.name)) : DEFAULT_CATEGORIES;
  };
  catsCache = run().catch((err) => {
    catsCache = null;
    throw err;
  });
  return catsCache;
}

export async function saveCategory(input) {
  const name = input.name.trim();
  const slug = slugify(input.slug || name);
  if (!name || !slug) throw new Error('Category name is required.');
  const data = { name, slug, description: (input.description || '').trim(), icon: input.icon || 'folder' };

  if (isDemo) {
    const rows = load('categories', DEFAULT_CATEGORIES);
    const exists = rows.some((c) => c.id === (input.id || slug));
    if (!input.id && rows.some((c) => c.slug === slug)) throw new Error('A category with this slug already exists.');
    save(
      'categories',
      exists ? rows.map((c) => (c.id === (input.id || slug) ? { ...c, ...data, slug: c.slug } : c)) : [...rows, { id: slug, ...data }],
    );
  } else {
    const { fs, db } = await getFirebase();
    const id = input.id || slug;
    if (!input.id) {
      const existing = await fs.getDoc(fs.doc(db, 'categories', id));
      if (existing.exists()) throw new Error('A category with this slug already exists.');
    }
    await fs.setDoc(fs.doc(db, 'categories', id), input.id ? { ...data, slug: input.slug } : data, { merge: true });
  }
  invalidateCache();
}

export async function deleteCategory(id) {
  if (isDemo) {
    save('categories', load('categories', DEFAULT_CATEGORIES).filter((c) => c.id !== id));
  } else {
    const { fs, db } = await getFirebase();
    await fs.deleteDoc(fs.doc(db, 'categories', id));
  }
  invalidateCache();
}

/* ───────────────────────── newsletter & contact ───────────────────────── */

/** @returns {'ok' | 'exists'} */
export async function subscribe(email, source = 'site') {
  const clean = String(email).trim().toLowerCase();
  if (!isValidEmail(clean)) throw new Error('Please enter a valid email address.');

  if (isDemo) {
    const rows = load('subscribers', []);
    if (rows.some((s) => s.email === clean)) return 'exists';
    save('subscribers', [{ id: newId(), email: clean, source, createdAt: Date.now() }, ...rows]);
    return 'ok';
  }
  const { fs, db } = await getFirebase();
  try {
    // The document id is the email, so a repeat sign-up becomes an (denied) update = "already subscribed".
    await fs.setDoc(fs.doc(db, 'subscribers', encodeURIComponent(clean)), {
      email: clean,
      source,
      createdAt: fs.serverTimestamp(),
    });
    return 'ok';
  } catch (err) {
    if (err?.code === 'permission-denied') return 'exists';
    throw err;
  }
}

export async function sendMessage({ name, email, subject, message }) {
  if (!name?.trim() || !subject?.trim() || !message?.trim()) throw new Error('Please fill in all fields.');
  if (!isValidEmail(email)) throw new Error('Please enter a valid email address.');
  const data = {
    name: name.trim().slice(0, 120),
    email: email.trim().slice(0, 254),
    subject: subject.trim().slice(0, 200),
    message: message.trim().slice(0, 5000),
  };
  if (isDemo) {
    save('messages', [{ id: newId(), ...data, createdAt: Date.now() }, ...load('messages', [])]);
    return;
  }
  const { fs, db } = await getFirebase();
  await fs.addDoc(fs.collection(db, 'messages'), { ...data, createdAt: fs.serverTimestamp() });
}

/* ───────────────────────── analytics ───────────────────────── */

export async function trackPageView() {
  const day = dayKey();
  try {
    if (isDemo) {
      const map = load('analytics', {});
      save('analytics', { ...map, [day]: (map[day] || 0) + 1 });
      return;
    }
    const { fs, db } = await getFirebase();
    const ref = fs.doc(db, 'analytics', day);
    try {
      await fs.updateDoc(ref, { views: fs.increment(1) });
    } catch (err) {
      if (err?.code === 'not-found') await fs.setDoc(ref, { date: day, views: 1 });
      else throw err;
    }
  } catch (err) {
    console.warn('Page view tracking skipped:', err?.code || err);
  }
}

export async function getDailyViews(days = 14) {
  let map = {};
  if (isDemo) {
    map = load('analytics', {});
  } else {
    const { fs, db } = await getFirebase();
    const snap = await fs.getDocs(
      fs.query(fs.collection(db, 'analytics'), fs.orderBy(fs.documentId(), 'desc'), fs.limit(Math.max(days, 30))),
    );
    snap.forEach((d) => {
      map[d.id] = Number(d.data().views) || 0;
    });
  }
  const out = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = dayKey(d);
    out.push({ date: key, views: map[key] || 0 });
  }
  return out;
}

/* ───────────────────────── admin: users / inbox ───────────────────────── */

export async function listUsers() {
  if (isDemo) {
    return load('users', [])
      .map(({ password, ...u }) => ({ ...u, createdAt: toMs(u.createdAt) }))
      .sort(byNewest);
  }
  const { fs, db } = await getFirebase();
  const snap = await fs.getDocs(fs.collection(db, 'users'));
  return snap.docs.map((d) => ({ uid: d.id, ...d.data(), createdAt: toMs(d.data().createdAt) })).sort(byNewest);
}

export async function updateUserRole(uid, role) {
  if (!['admin', 'user'].includes(role)) throw new Error('Invalid role');
  if (isDemo) {
    save('users', load('users', []).map((u) => (u.uid === uid ? { ...u, role } : u)));
    return;
  }
  const { fs, db } = await getFirebase();
  await fs.updateDoc(fs.doc(db, 'users', uid), { role });
}

export async function deleteUserProfile(uid) {
  if (isDemo) {
    save('users', load('users', []).filter((u) => u.uid !== uid));
    return;
  }
  const { fs, db } = await getFirebase();
  await fs.deleteDoc(fs.doc(db, 'users', uid));
}

async function listCollection(name) {
  if (isDemo) return load(name, []).map((r) => ({ ...r, createdAt: toMs(r.createdAt) })).sort(byNewest);
  const { fs, db } = await getFirebase();
  const snap = await fs.getDocs(fs.collection(db, name));
  return snap.docs.map((d) => ({ id: d.id, ...d.data(), createdAt: toMs(d.data().createdAt) })).sort(byNewest);
}

async function removeFromCollection(name, id) {
  if (isDemo) {
    save(name, load(name, []).filter((r) => r.id !== id));
    return;
  }
  const { fs, db } = await getFirebase();
  await fs.deleteDoc(fs.doc(db, name, id));
}

export const listSubscribers = () => listCollection('subscribers');
export const deleteSubscriber = (id) => removeFromCollection('subscribers', id);
export const listMessages = () => listCollection('messages');
export const deleteMessage = (id) => removeFromCollection('messages', id);

/* ───────────────────────── storage ───────────────────────── */

const MAX_UPLOAD = 5 * 1024 * 1024;

function resizeToDataUrl(file, maxWidth = 1400, quality = 0.82) {
  return new Promise((resolve, reject) => {
    if (file.type === 'image/svg+xml' || file.type === 'image/gif') {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('Could not read the file.'));
      reader.readAsDataURL(file);
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxWidth / img.width);
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('That file is not a valid image.'));
    };
    img.src = url;
  });
}

/** Uploads an image and resolves to its public URL. */
export async function uploadImage(file, onProgress) {
  if (!file?.type?.startsWith('image/')) throw new Error('Please choose an image file.');
  if (file.size > MAX_UPLOAD) throw new Error('Image is larger than 5 MB.');

  if (isDemo) {
    onProgress?.(40);
    const url = await resizeToDataUrl(file);
    onProgress?.(100);
    return url;
  }
  const { storage, stMod } = await getFirebase();
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const ref = stMod.ref(storage, `posts/${Date.now()}-${safeName}`);
  const task = stMod.uploadBytesResumable(ref, file, {
    contentType: file.type,
    cacheControl: 'public,max-age=31536000',
  });
  await new Promise((resolve, reject) => {
    task.on(
      'state_changed',
      (s) => onProgress?.(Math.round((s.bytesTransferred / s.totalBytes) * 100)),
      reject,
      resolve,
    );
  });
  return stMod.getDownloadURL(task.snapshot.ref);
}

/* ───────────────────────── seeding / reset ───────────────────────── */

/** Firebase mode: writes default categories + sample posts. Demo mode: resets the demo data. */
export async function seedSampleData() {
  if (isDemo) {
    resetDemo();
    invalidateCache();
    return { posts: load('posts', []).length };
  }
  const { fs, db } = await getFirebase();
  const seed = buildSeed(Date.now());
  const batch = fs.writeBatch(db);
  seed.categories.forEach((c) => {
    const { id, ...data } = c;
    batch.set(fs.doc(db, 'categories', id), data, { merge: true });
  });
  seed.posts.forEach((p) => {
    // eslint-disable-next-line no-unused-vars
    const { id, ...data } = p;
    batch.set(fs.doc(fs.collection(db, 'posts')), data);
  });
  await batch.commit();
  invalidateCache();
  return { posts: seed.posts.length };
}
