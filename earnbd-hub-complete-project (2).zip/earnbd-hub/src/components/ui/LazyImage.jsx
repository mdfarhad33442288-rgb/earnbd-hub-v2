import { useState } from 'react';
import { coverFor } from '../../lib/cover';

/**
 * Lazy-loaded image with a shimmer placeholder, fade-in and graceful fallback.
 * Give the parent an aspect ratio (e.g. `aspect-[16/9]`) to avoid layout shift.
 */
export default function LazyImage({ src, alt = '', className = '', priority = false, fallbackSeed = 'earnbd' }) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);
  const finalSrc = failed || !src ? coverFor(fallbackSeed) : src;

  return (
    <span className={`relative block h-full w-full overflow-hidden bg-slate-100 dark:bg-slate-800 ${loaded ? '' : 'animate-pulse'}`}>
      <img
        src={finalSrc}
        alt={alt}
        loading={priority ? 'eager' : 'lazy'}
        fetchpriority={priority ? 'high' : 'auto'}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={`h-full w-full object-cover transition duration-700 ${loaded ? 'opacity-100' : 'opacity-0'} ${className}`}
      />
    </span>
  );
}
