import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Search, X } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { searchPosts } from '../../lib/search';

/** Instant search overlay. Opens from the header button, or with "/" or Ctrl/Cmd+K. */
export default function SearchModal({ open, onClose }) {
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);
  const navigate = useNavigate();
  const { posts, getCategory } = useData();

  const results = useMemo(() => searchPosts(posts, query, 6), [posts, query]);

  useEffect(() => {
    if (!open) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => inputRef.current?.focus(), 30);
    const onKey = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      clearTimeout(t);
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  useEffect(() => {
    if (!open) setQuery('');
  }, [open]);

  if (!open) return null;

  function submit(e) {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    onClose();
    navigate(`/search?q=${encodeURIComponent(q)}`);
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center px-4 pt-[10vh]" role="dialog" aria-modal="true" aria-label="Search">
      <button type="button" aria-label="Close search" onClick={onClose} className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm animate-fade-in" />
      <div className="card relative w-full max-w-xl animate-fade-up overflow-hidden shadow-2xl">
        <form onSubmit={submit} className="flex items-center gap-3 border-b border-slate-200 px-4 dark:border-slate-800">
          <Search className="h-5 w-5 shrink-0 text-slate-400" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search articles, tools, jobs…"
            className="h-14 w-full bg-transparent text-base text-slate-900 outline-none placeholder:text-slate-400 dark:text-white"
            aria-label="Search articles"
          />
          <button type="button" onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </form>

        <div className="max-h-[55vh] overflow-y-auto p-2">
          {!query.trim() && <p className="px-3 py-6 text-center text-sm text-slate-500">Start typing to search {posts.length} articles.</p>}
          {query.trim() && !results.length && (
            <p className="px-3 py-6 text-center text-sm text-slate-500">No results for “{query}”. Try another keyword.</p>
          )}
          {results.map((post) => (
            <Link
              key={post.id}
              to={`/blog/${post.slug}`}
              onClick={onClose}
              className="flex items-center justify-between gap-3 rounded-xl px-3 py-2.5 transition hover:bg-brand-50 dark:hover:bg-slate-800"
            >
              <span className="min-w-0">
                <span className="block truncate text-sm font-semibold text-slate-900 dark:text-slate-100">{post.title}</span>
                <span className="block text-xs text-brand-600 dark:text-brand-400">{getCategory(post.category).name}</span>
              </span>
              <ArrowRight className="h-4 w-4 shrink-0 text-slate-400" />
            </Link>
          ))}
          {query.trim() && results.length > 0 && (
            <button type="button" onClick={submit} className="mt-1 w-full rounded-xl px-3 py-2.5 text-left text-sm font-semibold text-brand-600 hover:bg-brand-50 dark:text-brand-400 dark:hover:bg-slate-800">
              See all results for “{query}” →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
