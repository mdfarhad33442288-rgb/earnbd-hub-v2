import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Cookie } from 'lucide-react';
import { applyConsent, getConsent, setConsent } from '../../lib/consent';

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    applyConsent();
    setVisible(getConsent() === null);
  }, []);

  if (!visible) return null;
  const choose = (value) => {
    setConsent(value);
    setVisible(false);
  };

  return (
    <div role="dialog" aria-label="Cookie consent" className="fixed inset-x-3 bottom-3 z-[60] mx-auto max-w-3xl animate-fade-up">
      <div className="card flex flex-col gap-4 p-4 shadow-2xl sm:flex-row sm:items-center sm:p-5">
        <span className="hidden h-11 w-11 shrink-0 place-items-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/10 sm:grid">
          <Cookie className="h-5 w-5" />
        </span>
        <p className="flex-1 text-sm text-slate-600 dark:text-slate-300">
          We use cookies for analytics and to show ads (Google AdSense). You can accept personalised ads or choose non-personalised ones.{' '}
          <Link to="/privacy-policy" className="font-semibold text-brand-600 underline">
            Privacy Policy
          </Link>
        </p>
        <div className="flex gap-2">
          <button type="button" onClick={() => choose('denied')} className="btn btn-outline btn-sm">
            Non-personalised
          </button>
          <button type="button" onClick={() => choose('granted')} className="btn btn-primary btn-sm">
            Accept
          </button>
        </div>
      </div>
    </div>
  );
}
