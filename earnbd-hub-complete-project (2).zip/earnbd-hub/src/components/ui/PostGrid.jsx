import { Fragment } from 'react';
import PostCard from './PostCard';
import { PostGridSkeleton } from './Skeletons';
import { EmptyState, ErrorState } from './ErrorState';
import AdSlot from '../ads/AdSlot';

/** Grid of post cards with loading, error and empty states and optional in-feed ads. */
export default function PostGrid({
  posts,
  loading,
  error,
  onRetry,
  columns = 'sm:grid-cols-2 lg:grid-cols-3',
  adEvery = 0,
  emptyTitle = 'No posts found',
  emptyMessage = 'Try a different search or check back soon for new articles.',
  skeletonCount = 6,
}) {
  if (loading) return <PostGridSkeleton count={skeletonCount} columns={columns} />;
  if (error) return <ErrorState onRetry={onRetry} />;
  if (!posts.length) return <EmptyState title={emptyTitle} message={emptyMessage} />;

  return (
    <div className={`grid gap-6 ${columns}`}>
      {posts.map((post, i) => (
        <Fragment key={post.id}>
          <PostCard post={post} priority={i < 2} />
          {adEvery > 0 && (i + 1) % adEvery === 0 && i !== posts.length - 1 && (
            <div className="col-span-full">
              <AdSlot slot="inFeed" />
            </div>
          )}
        </Fragment>
      ))}
    </div>
  );
}
