import { useState } from 'react';
import { CheckCircle2, Loader2, Mail, Send } from 'lucide-react';
import { subscribe } from '../../services/db';

/** variant: 'card' (sidebar) | 'band' (full-width CTA on blue) | 'inline' (footer, on dark) */
export default function Newsletter({ variant = 'card', source = 'site' }) {
  const [email, setEmail] = useState('');
  const [state, setState] = useState({ status: 'idle', message: '' });

  async function onSubmit(e) {
    e.preventDefault();
    if (state.status === 'loading') return;
    setState({ status: 'loading', message: '' });
    try {
      const result = await subscribe(email, source);
      setState({
        status: 'success',
        message: result === 'exists' ? 'You are already subscribed – thank you!' : 'Thanks for subscribing! Watch your inbox.',
      });
      setEmail('');
    } catch (err) {
      setState({ status: 'error', message: err.message || 'Could not subscribe. Please try again.' });
    }
  }

  const form = (
    <form onSubmit={onSubmit} noValidate className={variant === 'card' ? 'space-y-3' : 'flex flex-col gap-3 sm:flex-row'}>
      <label className="sr-only" htmlFor={`nl-${variant}`}>
        Email address
      </label>
      <input
        id={`nl-${variant}`}
        type="email"
        required
        autoComplete="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@example.com"
        className={`input ${variant !== 'card' ? 'sm:flex-1' : ''} ${variant === 'inline' ? '!border-slate-700 !bg-slate-800 !text-white' : ''}`}
      />
      <button
        type="submit"
        disabled={state.status === 'loading'}
        className={`btn ${variant === 'band' ? 'btn-white' : 'btn-primary'} ${variant === 'card' ? 'w-full' : ''}`}
      >
        {state.status === 'loading' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        Subscribe
      </button>
    </form>
  );

  const feedback = state.message && (
    <p
      role="status"
      className={`mt-3 flex items-center gap-2 text-sm ${
        state.status === 'success'
          ? variant === 'card'
            ? 'text-emerald-600'
            : 'text-emerald-300'
          : variant === 'card'
            ? 'text-red-600'
            : 'text-red-200'
      }`}
    >
      {state.status === 'success' && <CheckCircle2 className="h-4 w-4" />}
      {state.message}
    </p>
  );

  if (variant === 'band') {
    return (
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-600 via-brand-700 to-brand-900 px-6 py-12 text-white shadow-glow sm:px-12">
        <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-2xl" />
        <div className="relative mx-auto max-w-2xl text-center">
          <span className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-white/15">
            <Mail className="h-6 w-6" />
          </span>
          <h2 className="text-2xl !text-white sm:text-3xl">Get the best guides in your inbox</h2>
          <p className="mt-2 text-brand-100">
            Free weekly tips on AI tools, online income, freelancing and jobs. No spam – unsubscribe anytime.
          </p>
          <div className="mt-6 text-left">{form}</div>
          {feedback}
        </div>
      </section>
    );
  }

  if (variant === 'inline') {
    return (
      <div>
        {form}
        {feedback}
      </div>
    );
  }

  return (
    <section className="card overflow-hidden">
      <div className="bg-gradient-to-br from-brand-600 to-brand-800 p-5 text-white">
        <Mail className="mb-2 h-6 w-6" />
        <h3 className="text-lg !text-white">Join the newsletter</h3>
        <p className="mt-1 text-sm text-brand-100">Weekly tips, tools and job alerts. Free.</p>
      </div>
      <div className="p-5">
        {form}
        {feedback}
      </div>
    </section>
  );
}
