import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, BadgeCheck, Search, Sparkles, TrendingUp, Zap } from 'lucide-react';
import { categoryPath } from '../../config/site';
import { useData } from '../../context/DataContext';
import CategoryIcon from './CategoryIcon';

export default function Hero() {
  const [q, setQ] = useState('');
  const navigate = useNavigate();
  const { categories, posts } = useData();

  function onSubmit(e) {
    e.preventDefault();
    if (q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
  }

  return (
    <section className="relative isolate overflow-hidden bg-gradient-to-br from-brand-700 via-brand-800 to-brand-950 text-white">
      {/* decorative background */}
      <div className="pointer-events-none absolute -left-24 -top-24 -z-10 h-96 w-96 animate-blob rounded-full bg-sky-400/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-32 right-0 -z-10 h-[28rem] w-[28rem] animate-blob rounded-full bg-brand-400/30 blur-3xl [animation-delay:-6s]" />
      <div
        className="pointer-events-none absolute inset-0 -z-10 opacity-[0.15]"
        style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, #fff 1px, transparent 0)',
          backgroundSize: '28px 28px',
        }}
      />

      <div className="container-page grid items-center gap-12 py-16 sm:py-20 lg:grid-cols-[1.15fr_0.85fr] lg:py-28">
        <div className="animate-fade-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-semibold backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-sky-300" /> Free guides for learners &amp; earners in Bangladesh
          </span>
          <h1 className="mt-5 text-4xl font-extrabold leading-[1.1] !text-white sm:text-5xl lg:text-6xl">
            Learn smarter. <span className="bg-gradient-to-r from-sky-300 to-white bg-clip-text text-transparent">Earn online.</span> Grow your career.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-7 text-brand-100 sm:text-lg">
            Practical, beginner-friendly guides on AI tools, online income, freelancing, job circulars and education – written to help you take the next step.
          </p>

          <form onSubmit={onSubmit} role="search" className="mt-8 flex max-w-xl items-center gap-2 rounded-2xl bg-white p-2 shadow-2xl shadow-brand-950/40">
            <label htmlFor="hero-search" className="sr-only">
              Search articles
            </label>
            <Search className="ml-3 h-5 w-5 shrink-0 text-slate-400" />
            <input
              id="hero-search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search AI tools, freelancing, jobs…"
              className="h-11 min-w-0 flex-1 bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400 sm:text-base"
            />
            <button type="submit" className="btn btn-primary">
              Search
            </button>
          </form>

          <div className="mt-7 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-brand-100">
            <span className="inline-flex items-center gap-2">
              <BadgeCheck className="h-4 w-4 text-sky-300" /> {posts.length || '10+'} free guides
            </span>
            <span className="inline-flex items-center gap-2">
              <Zap className="h-4 w-4 text-sky-300" /> Updated regularly
            </span>
            <span className="inline-flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-sky-300" /> Beginner friendly
            </span>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/blog" className="btn btn-white">
              Browse all articles <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/online-income" className="btn border border-white/30 bg-white/10 text-white backdrop-blur hover:bg-white/20">
              Start earning
            </Link>
          </div>
        </div>

        {/* floating category cards */}
        <div className="relative hidden lg:block" aria-hidden={categories.length === 0}>
          <div className="grid grid-cols-2 gap-4">
            {categories.slice(0, 4).map((c, i) => (
              <Link
                key={c.id}
                to={categoryPath(c.slug)}
                style={{ animationDelay: `${i * 0.8}s` }}
                className={`group animate-float rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur-md transition hover:bg-white/20 ${i % 2 ? 'mt-8' : ''}`}
              >
                <span className="mb-3 grid h-11 w-11 place-items-center rounded-xl bg-white text-brand-700 shadow-lg transition group-hover:scale-110">
                  <CategoryIcon name={c.icon} className="h-5 w-5" />
                </span>
                <p className="font-bold text-white">{c.name}</p>
                <p className="mt-1 line-clamp-2 text-xs text-brand-100">{c.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <svg className="block w-full text-white dark:text-slate-950" viewBox="0 0 1440 60" preserveAspectRatio="none" aria-hidden="true" height="48">
        <path fill="currentColor" d="M0 60V30c240 30 480 30 720 10s480-30 720-10v30z" />
      </svg>
    </section>
  );
}
