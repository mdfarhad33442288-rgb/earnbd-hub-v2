export function PostCardSkeleton() {
  return (
    <div className="card overflow-hidden" aria-hidden="true">
      <div className="skeleton aspect-[16/9] w-full rounded-none" />
      <div className="space-y-3 p-5">
        <div className="skeleton h-3 w-1/3" />
        <div className="skeleton h-5 w-11/12" />
        <div className="skeleton h-5 w-2/3" />
        <div className="skeleton h-3 w-full" />
        <div className="skeleton h-3 w-5/6" />
      </div>
    </div>
  );
}

export function PostGridSkeleton({ count = 6, columns = 'sm:grid-cols-2 lg:grid-cols-3' }) {
  return (
    <div className={`grid gap-6 ${columns}`} role="status" aria-label="Loading posts">
      {Array.from({ length: count }, (_, i) => (
        <PostCardSkeleton key={i} />
      ))}
    </div>
  );
}

export function ListSkeleton({ rows = 4 }) {
  return (
    <div className="space-y-4" aria-hidden="true">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="flex gap-3">
          <div className="skeleton h-16 w-20 shrink-0" />
          <div className="flex-1 space-y-2 py-1">
            <div className="skeleton h-3.5 w-full" />
            <div className="skeleton h-3.5 w-2/3" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ArticleSkeleton() {
  return (
    <div className="space-y-5" role="status" aria-label="Loading article">
      <div className="skeleton h-4 w-40" />
      <div className="skeleton h-10 w-11/12" />
      <div className="skeleton h-10 w-2/3" />
      <div className="skeleton h-4 w-64" />
      <div className="skeleton aspect-[16/9] w-full" />
      {Array.from({ length: 6 }, (_, i) => (
        <div key={i} className="skeleton h-4 w-full" style={{ width: `${70 + ((i * 13) % 30)}%` }} />
      ))}
    </div>
  );
}

export function TableSkeleton({ rows = 6 }) {
  return (
    <div className="space-y-3 p-4" aria-hidden="true">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="skeleton h-10 w-full" />
      ))}
    </div>
  );
}
