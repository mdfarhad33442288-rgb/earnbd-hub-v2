import { Link } from 'react-router-dom';
import { SITE } from '../../config/site';

export function LogoMark({ className = 'h-9 w-9' }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="ebd-logo-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3b82f6" />
          <stop offset="1" stopColor="#1d4ed8" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill="url(#ebd-logo-g)" />
      <path d="M20 44V20h20v5.5H26.2v4.3h12.1v5.3H26.2v3.4H41V44z" fill="#fff" />
      <path d="M44 20l6 6-6 6" fill="none" stroke="#bfdbfe" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function Logo({ to = '/', light = false }) {
  return (
    <Link to={to} className="group inline-flex items-center gap-2.5" aria-label={`${SITE.name} home`}>
      <LogoMark className="h-9 w-9 transition group-hover:rotate-6 group-hover:scale-105" />
      <span className={`text-lg font-extrabold tracking-tight ${light ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
        EarnBD<span className={light ? 'text-brand-200' : 'text-brand-600 dark:text-brand-400'}> Hub</span>
      </span>
    </Link>
  );
}
