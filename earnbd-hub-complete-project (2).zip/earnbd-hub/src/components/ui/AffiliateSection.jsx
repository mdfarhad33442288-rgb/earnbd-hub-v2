import { ExternalLink, Star } from 'lucide-react';
import { AFFILIATES } from '../../config/site';
import CategoryIcon from './CategoryIcon';
import Reveal from './Reveal';

/** Recommended-products block. Edit AFFILIATES in src/config/site.js with your own links. */
export default function AffiliateSection({ compact = false }) {
  const items = compact ? AFFILIATES.slice(0, 2) : AFFILIATES;
  return (
    <section aria-labelledby="affiliate-heading" className={compact ? 'my-10' : ''}>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="section-eyebrow">Recommended tools</p>
          <h2 id="affiliate-heading" className="mt-1 text-2xl sm:text-3xl">
            Tools &amp; resources we recommend
          </h2>
        </div>
        <p className="max-w-sm text-xs text-slate-500 dark:text-slate-400">
          Affiliate disclosure: we may earn a commission if you buy through these links, at no extra cost to you.
        </p>
      </div>
      <div className={`grid gap-5 ${compact ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-4'}`}>
        {items.map((item, i) => (
          <Reveal key={item.id} delay={i * 80}>
            <div className="card card-hover flex h-full flex-col p-5">
              <div className="mb-4 flex items-start justify-between">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-glow">
                  <CategoryIcon name={item.icon} className="h-6 w-6" />
                </span>
                <span className="badge">{item.badge}</span>
              </div>
              <h3 className="text-lg">{item.name}</h3>
              <div className="mt-1 flex items-center gap-1 text-amber-500" aria-label={`Rated ${item.rating} out of 5`}>
                <Star className="h-4 w-4 fill-current" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{item.rating}</span>
              </div>
              <p className="mt-2 flex-1 text-sm text-slate-600 dark:text-slate-400">{item.description}</p>
              <a
                href={item.url}
                target="_blank"
                rel="sponsored nofollow noopener noreferrer"
                className="btn btn-primary mt-5 w-full"
              >
                {item.cta} <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
