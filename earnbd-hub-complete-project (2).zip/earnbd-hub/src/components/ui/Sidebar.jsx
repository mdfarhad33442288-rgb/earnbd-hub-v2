import { Link } from 'react-router-dom';
import { TrendingUp } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { categoryPath } from '../../config/site';
import AdSlot from '../ads/AdSlot';
import CategoryIcon from './CategoryIcon';
import Newsletter from './Newsletter';
import PostCard from './PostCard';
import { ListSkeleton } from './Skeletons';

/** Shared sidebar: popular posts, categories, newsletter and a sticky ad. */
export default function Sidebar({ excludeId, showNewsletter = true }) {
  const { popular, categories, posts, loading } = useData();
  const top = popular.filter((p) => p.id !== excludeId).slice(0, 5);

  return (
    <aside className="space-y-8 lg:sticky lg:top-24 lg:self-start" aria-label="Sidebar">
      <section className="card p-5">
        <h2 className="mb-4 flex items-center gap-2 text-base">
          <TrendingUp className="h-5 w-5 text-brand-600" /> Popular posts
        </h2>
        {loading ? (
          <ListSkeleton rows={4} />
        ) : (
          <div className="space-y-4">
            {top.map((p) => (
              <PostCard key={p.id} post={p} variant="compact" />
            ))}
          </div>
        )}
      </section>

      <AdSlot slot="sidebar" className="!my-0" />

      <section className="card p-5">
        <h2 className="mb-3 text-base">Categories</h2>
        <ul className="space-y-1">
          {categories.map((c) => (
            <li key={c.id}>
              <Link
                to={categoryPath(c.slug)}
                className="flex items-center justify-between rounded-xl px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-brand-50 hover:text-brand-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <span className="flex items-center gap-2.5">
                  <CategoryIcon name={c.icon} className="h-4 w-4 text-brand-600" /> {c.name}
                </span>
                <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500 dark:bg-slate-800">
                  {posts.filter((p) => p.category === c.slug).length}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {showNewsletter && <Newsletter source="sidebar" />}
    </aside>
  );
}
