import { useEffect } from 'react';
import { AlertTriangle } from 'lucide-react';

export default function ConfirmDialog({ open, title = 'Are you sure?', message, confirmLabel = 'Delete', busy = false, onConfirm, onCancel }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && onCancel();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[75] grid place-items-center px-4" role="alertdialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label="Cancel" onClick={onCancel} className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm animate-fade-in" />
      <div className="card relative w-full max-w-sm animate-fade-up p-6 text-center">
        <span className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-red-50 text-red-600 dark:bg-red-500/10">
          <AlertTriangle className="h-6 w-6" />
        </span>
        <h3 className="text-lg">{title}</h3>
        {message && <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{message}</p>}
        <div className="mt-6 flex gap-3">
          <button type="button" className="btn btn-outline flex-1" onClick={onCancel} disabled={busy}>
            Cancel
          </button>
          <button type="button" className="btn btn-danger flex-1" onClick={onConfirm} disabled={busy}>
            {busy ? 'Working…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
