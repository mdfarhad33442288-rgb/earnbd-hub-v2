import { Link } from 'react-router-dom';
import { ArrowRight, Megaphone } from 'lucide-react';
import { SPONSOR_FALLBACKS } from '../../config/site';
import { useData } from '../../context/DataContext';
import PostCard from './PostCard';

/**
 * Sponsored content block. Shows posts that are flagged "Sponsored" in the admin editor;
 * when there are none it shows "advertise with us" cards so the space still earns.
 */
export default function SponsoredSection() {
  const { sponsored, loading } = useData();
  if (loading) return null;
  const posts = sponsored.slice(0, 3);

  return (
    <section aria-labelledby="sponsored-heading" className="rounded-3xl border border-amber-200 bg-amber-50/60 p-6 dark:border-amber-500/20 dark:bg-amber-500/5 sm:p-8">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-amber-400 text-amber-950">
            <Megaphone className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-amber-700 dark:text-amber-400">Sponsored</p>
            <h2 id="sponsored-heading" className="text-xl sm:text-2xl">
              From our partners
            </h2>
          </div>
        </div>
        <Link to="/contact?subject=Sponsored%20content" className="btn btn-outline btn-sm">
          Advertise with us <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      {posts.length ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {posts.map((p) => (
            <PostCard key={p.id} post={p} />
          ))}
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2">
          {SPONSOR_FALLBACKS.map((s) => (
            <Link key={s.id} to={s.url} className="card card-hover block p-6">
              <span className="badge !bg-amber-100 !text-amber-800">{s.sponsor}</span>
              <h3 className="mt-3 text-lg">{s.title}</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{s.excerpt}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-600">
                Learn more <ArrowRight className="h-4 w-4" />
              </span>
            </Link>
          ))}
        </div>
      )}
      <p className="mt-5 text-xs text-slate-500 dark:text-slate-400">
        Sponsored content is paid for by advertisers. It is clearly labelled and does not influence our editorial reviews.
      </p>
    </section>
  );
}
