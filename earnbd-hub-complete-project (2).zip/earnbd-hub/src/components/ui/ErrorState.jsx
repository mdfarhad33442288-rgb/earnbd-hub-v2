import { AlertTriangle, RefreshCw, SearchX } from 'lucide-react';

/** Inline error block with a retry button (used when data fails to load). */
export function ErrorState({ title = 'Could not load content', message, onRetry }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center" role="alert">
      <span className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-red-50 text-red-600 dark:bg-red-500/10">
        <AlertTriangle className="h-6 w-6" />
      </span>
      <h3 className="text-lg">{title}</h3>
      <p className="mt-1 max-w-md text-sm text-slate-500 dark:text-slate-400">
        {message || 'Please check your connection and try again.'}
      </p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="btn btn-primary btn-sm mt-5">
          <RefreshCw className="h-4 w-4" /> Try again
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title = 'Nothing here yet', message, children }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      <span className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/10">
        <SearchX className="h-6 w-6" />
      </span>
      <h3 className="text-lg">{title}</h3>
      {message && <p className="mt-1 max-w-md text-sm text-slate-500 dark:text-slate-400">{message}</p>}
      {children && <div className="mt-5">{children}</div>}
    </div>
  );
}
