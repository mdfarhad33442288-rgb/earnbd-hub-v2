import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { absoluteUrl } from '../../lib/utils';

/** items: [{ label, to? }] – the last item is the current page. A Home crumb is added automatically. */
export default function Breadcrumb({ items = [], className = '' }) {
  const trail = [{ label: 'Home', to: '/' }, ...items];
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: trail.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.label,
      ...(item.to ? { item: absoluteUrl(item.to) } : {}),
    })),
  };

  return (
    <nav aria-label="Breadcrumb" className={`text-sm ${className}`}>
      <Helmet>
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>
      <ol className="flex flex-wrap items-center gap-1.5 text-slate-500 dark:text-slate-400">
        {trail.map((item, i) => {
          const last = i === trail.length - 1;
          return (
            <li key={`${item.label}-${i}`} className="flex items-center gap-1.5">
              {i === 0 ? (
                <Link to="/" className="inline-flex items-center gap-1 hover:text-brand-600 dark:hover:text-brand-400">
                  <Home className="h-3.5 w-3.5" />
                  <span className="sr-only sm:not-sr-only">Home</span>
                </Link>
              ) : last || !item.to ? (
                <span aria-current="page" className="max-w-[16rem] truncate font-medium text-slate-800 dark:text-slate-200 sm:max-w-md">
                  {item.label}
                </span>
              ) : (
                <Link to={item.to} className="hover:text-brand-600 dark:hover:text-brand-400">
                  {item.label}
                </Link>
              )}
              {!last && <ChevronRight className="h-3.5 w-3.5 text-slate-300 dark:text-slate-600" aria-hidden="true" />}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
