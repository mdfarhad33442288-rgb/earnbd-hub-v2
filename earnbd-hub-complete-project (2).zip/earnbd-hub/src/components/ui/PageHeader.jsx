import Breadcrumb from './Breadcrumb';

/** Blue gradient page banner with breadcrumb, used by listing and static pages. */
export default function PageHeader({ title, subtitle, eyebrow, crumbs = [], children, icon }) {
  return (
    <header className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-sky-50 dark:from-slate-900 dark:via-slate-950 dark:to-brand-950">
      <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brand-200/50 blur-3xl dark:bg-brand-600/20" />
      <div className="container-page relative py-10 sm:py-14">
        <Breadcrumb items={crumbs} className="mb-5" />
        <div className="flex items-start gap-4">
          {icon && (
            <span className="hidden h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-glow sm:grid">
              {icon}
            </span>
          )}
          <div className="max-w-3xl animate-fade-up">
            {eyebrow && <p className="section-eyebrow mb-2">{eyebrow}</p>}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl">{title}</h1>
            {subtitle && <p className="mt-3 text-base text-slate-600 dark:text-slate-400 sm:text-lg">{subtitle}</p>}
            {children}
          </div>
        </div>
      </div>
    </header>
  );
}
