import { Bot, Briefcase, Folder, GraduationCap, Laptop, Wallet, Globe, Sparkles, FileText, Megaphone } from 'lucide-react';

export const ICONS = {
  bot: Bot,
  wallet: Wallet,
  laptop: Laptop,
  briefcase: Briefcase,
  graduation: GraduationCap,
  folder: Folder,
  globe: Globe,
  sparkles: Sparkles,
  file: FileText,
  megaphone: Megaphone,
};

export default function CategoryIcon({ name = 'folder', className = 'h-5 w-5' }) {
  const Icon = ICONS[name] || Folder;
  return <Icon className={className} aria-hidden="true" />;
}
