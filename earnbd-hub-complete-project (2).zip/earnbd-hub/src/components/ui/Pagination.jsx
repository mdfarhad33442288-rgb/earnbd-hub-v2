import { ChevronLeft, ChevronRight } from 'lucide-react';

function range(page, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages = new Set([1, 2, total - 1, total, page - 1, page, page + 1]);
  const sorted = [...pages].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);
  const out = [];
  sorted.forEach((p, i) => {
    if (i && p - sorted[i - 1] > 1) out.push('…');
    out.push(p);
  });
  return out;
}

export default function Pagination({ page, totalPages, onChange, className = '' }) {
  if (totalPages <= 1) return null;
  const base =
    'grid h-10 min-w-[2.5rem] place-items-center rounded-xl border px-3 text-sm font-semibold transition';
  return (
    <nav aria-label="Pagination" className={`flex flex-wrap items-center justify-center gap-2 ${className}`}>
      <button
        type="button"
        onClick={() => onChange(page - 1)}
        disabled={page <= 1}
        className={`${base} border-slate-200 bg-white hover:border-brand-300 hover:text-brand-700 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900`}
        aria-label="Previous page"
      >
        <ChevronLeft className="h-4 w-4" />
      </button>
      {range(page, totalPages).map((p, i) =>
        p === '…' ? (
          <span key={`gap-${i}`} className="px-1 text-slate-400" aria-hidden="true">
            …
          </span>
        ) : (
          <button
            key={p}
            type="button"
            onClick={() => onChange(p)}
            aria-current={p === page ? 'page' : undefined}
            className={`${base} ${
              p === page
                ? 'border-brand-600 bg-brand-600 text-white shadow-glow'
                : 'border-slate-200 bg-white hover:border-brand-300 hover:text-brand-700 dark:border-slate-700 dark:bg-slate-900'
            }`}
          >
            {p}
          </button>
        ),
      )}
      <button
        type="button"
        onClick={() => onChange(page + 1)}
        disabled={page >= totalPages}
        className={`${base} border-slate-200 bg-white hover:border-brand-300 hover:text-brand-700 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900`}
        aria-label="Next page"
      >
        <ChevronRight className="h-4 w-4" />
      </button>
    </nav>
  );
}
