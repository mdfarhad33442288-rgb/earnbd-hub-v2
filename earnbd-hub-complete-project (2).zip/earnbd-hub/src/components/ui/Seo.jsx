import { Helmet } from 'react-helmet-async';
import { SITE } from '../../config/site';
import { absoluteUrl, truncate } from '../../lib/utils';

/**
 * Per-page SEO: <title>, meta description, canonical, Open Graph, Twitter Card and JSON-LD.
 * Pass `jsonLd` as an object or an array of Schema.org objects.
 */
export default function Seo({
  title,
  description = SITE.description,
  path,
  image,
  type = 'website',
  noindex = false,
  keywords,
  article,
  jsonLd,
}) {
  const fullTitle = title ? `${title} | ${SITE.name}` : `${SITE.name} – AI Tools, Online Income, Freelancing, Jobs & Education`;
  const desc = truncate(description, 160);
  const currentPath = path ?? (typeof window !== 'undefined' ? window.location.pathname : '/');
  const url = absoluteUrl(currentPath);
  const img = absoluteUrl(!image || image.startsWith('data:') ? '/og-default.png' : image);
  const schemas = jsonLd ? (Array.isArray(jsonLd) ? jsonLd : [jsonLd]) : [];

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={desc} />
      {keywords && <meta name="keywords" content={Array.isArray(keywords) ? keywords.join(', ') : keywords} />}
      <meta name="robots" content={noindex ? 'noindex,nofollow' : 'index,follow,max-image-preview:large'} />
      <link rel="canonical" href={url} />

      <meta property="og:site_name" content={SITE.name} />
      <meta property="og:type" content={type} />
      <meta property="og:title" content={title || fullTitle} />
      <meta property="og:description" content={desc} />
      <meta property="og:url" content={url} />
      <meta property="og:image" content={img} />
      <meta property="og:locale" content="en_US" />

      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title || fullTitle} />
      <meta name="twitter:description" content={desc} />
      <meta name="twitter:image" content={img} />

      {article?.publishedTime && <meta property="article:published_time" content={article.publishedTime} />}
      {article?.modifiedTime && <meta property="article:modified_time" content={article.modifiedTime} />}
      {article?.section && <meta property="article:section" content={article.section} />}
      {(article?.tags || []).map((t) => (
        <meta key={t} property="article:tag" content={t} />
      ))}

      {schemas.map((schema, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      ))}
    </Helmet>
  );
}

/** Site-wide structured data used on the home page. */
export function websiteSchema() {
  const base = absoluteUrl('/');
  return [
    {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: SITE.name,
      url: base,
      description: SITE.description,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${absoluteUrl('/search')}?q={search_term_string}`,
        'query-input': 'required name=search_term_string',
      },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: SITE.name,
      url: base,
      logo: absoluteUrl('/icon-512.png'),
      sameAs: Object.values(SITE.social),
    },
  ];
}
