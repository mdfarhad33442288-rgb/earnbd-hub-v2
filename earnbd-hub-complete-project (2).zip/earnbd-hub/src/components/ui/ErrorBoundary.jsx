import { Component } from 'react';
import { AlertTriangle, Home, RefreshCw } from 'lucide-react';

/** Catches render errors anywhere below it and shows a friendly full-page error screen. */
export default class ErrorBoundary extends Component {
  state = { error: null };

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error('Unhandled UI error:', error, info?.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4 dark:bg-slate-950">
        <div className="card max-w-md p-8 text-center">
          <span className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-red-50 text-red-600 dark:bg-red-500/10">
            <AlertTriangle className="h-7 w-7" />
          </span>
          <h1 className="text-2xl">Something went wrong</h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            An unexpected error occurred. Please reload the page – if the problem continues, try again in a few minutes.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <button type="button" className="btn btn-primary" onClick={() => window.location.reload()}>
              <RefreshCw className="h-4 w-4" /> Reload page
            </button>
            <a href="/" className="btn btn-outline">
              <Home className="h-4 w-4" /> Go home
            </a>
          </div>
        </div>
      </div>
    );
  }
}
