import { useState } from 'react';
import { Check, Facebook, Link2, Linkedin, MessageCircle, Send, Share2, Twitter } from 'lucide-react';
import { absoluteUrl } from '../../lib/utils';

export default function ShareButtons({ title, path, className = '' }) {
  const [copied, setCopied] = useState(false);
  const url = absoluteUrl(path || (typeof window !== 'undefined' ? window.location.pathname : '/'));
  const u = encodeURIComponent(url);
  const t = encodeURIComponent(title);

  const targets = [
    { name: 'Facebook', icon: Facebook, href: `https://www.facebook.com/sharer/sharer.php?u=${u}`, color: 'hover:bg-[#1877f2]' },
    { name: 'X (Twitter)', icon: Twitter, href: `https://twitter.com/intent/tweet?url=${u}&text=${t}`, color: 'hover:bg-slate-900' },
    { name: 'LinkedIn', icon: Linkedin, href: `https://www.linkedin.com/sharing/share-offsite/?url=${u}`, color: 'hover:bg-[#0a66c2]' },
    { name: 'WhatsApp', icon: MessageCircle, href: `https://wa.me/?text=${t}%20${u}`, color: 'hover:bg-[#25d366]' },
    { name: 'Telegram', icon: Send, href: `https://t.me/share/url?url=${u}&text=${t}`, color: 'hover:bg-[#229ed9]' },
  ];

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt('Copy this link:', url);
    }
  }

  async function nativeShare() {
    try {
      await navigator.share({ title, url });
    } catch {
      /* user cancelled */
    }
  }

  const btn =
    'grid h-10 w-10 place-items-center rounded-full bg-slate-100 text-slate-600 transition hover:-translate-y-0.5 hover:text-white dark:bg-slate-800 dark:text-slate-300';

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      <span className="mr-1 inline-flex items-center gap-1.5 text-sm font-semibold text-slate-700 dark:text-slate-200">
        <Share2 className="h-4 w-4" /> Share
      </span>
      {targets.map(({ name, icon: Icon, href, color }) => (
        <a key={name} href={href} target="_blank" rel="noopener noreferrer" aria-label={`Share on ${name}`} title={`Share on ${name}`} className={`${btn} ${color}`}>
          <Icon className="h-4 w-4" />
        </a>
      ))}
      <button type="button" onClick={copy} aria-label="Copy link" title="Copy link" className={`${btn} hover:bg-brand-600`}>
        {copied ? <Check className="h-4 w-4" /> : <Link2 className="h-4 w-4" />}
      </button>
      {typeof navigator !== 'undefined' && navigator.share && (
        <button type="button" onClick={nativeShare} aria-label="More sharing options" className={`${btn} hover:bg-brand-600 sm:hidden`}>
          <Share2 className="h-4 w-4" />
        </button>
      )}
      {copied && (
        <span role="status" className="text-xs font-medium text-emerald-600">
          Link copied!
        </span>
      )}
    </div>
  );
}
