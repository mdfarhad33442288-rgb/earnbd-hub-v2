import { Link } from 'react-router-dom';
import { Clock, Eye, Megaphone } from 'lucide-react';
import LazyImage from './LazyImage';
import { useData } from '../../context/DataContext';
import { postCover } from '../../lib/cover';
import { formatDate, formatNumber } from '../../lib/utils';

/** variant: 'default' (vertical card) | 'compact' (thumbnail row) | 'featured' (large overlay) */
export default function PostCard({ post, variant = 'default', priority = false }) {
  const { getCategory } = useData();
  const category = getCategory(post.category);
  const href = `/blog/${post.slug}`;

  if (variant === 'compact') {
    return (
      <Link to={href} className="group flex gap-3">
        <span className="block aspect-[4/3] w-24 shrink-0 overflow-hidden rounded-xl">
          <LazyImage src={postCover(post)} alt="" className="transition duration-500 group-hover:scale-110" fallbackSeed={post.slug} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="line-clamp-2 text-sm font-semibold leading-snug text-slate-900 transition group-hover:text-brand-600 dark:text-slate-100 dark:group-hover:text-brand-400">
            {post.title}
          </span>
          <span className="mt-1 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>{formatDate(post.createdAt)}</span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1">
              <Eye className="h-3 w-3" /> {formatNumber(post.views)}
            </span>
          </span>
        </span>
      </Link>
    );
  }

  if (variant === 'featured') {
    return (
      <article className="group relative isolate flex min-h-[22rem] overflow-hidden rounded-3xl shadow-soft transition duration-300 hover:shadow-lift lg:min-h-[28rem]">
        <div className="absolute inset-0 -z-20">
          <LazyImage src={postCover(post)} alt="" priority={priority} className="transition duration-700 group-hover:scale-105" fallbackSeed={post.slug} />
        </div>
        <div className="absolute inset-0 -z-10 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
        <div className="mt-auto p-6 sm:p-8">
          <span className="badge !bg-white/15 !text-white backdrop-blur">{category.name}</span>
          <h3 className="mt-3 text-2xl font-extrabold leading-tight !text-white sm:text-3xl">
            <Link to={href} className="after:absolute after:inset-0 hover:underline">
              {post.title}
            </Link>
          </h3>
          <p className="mt-2 line-clamp-2 max-w-2xl text-sm text-slate-200">{post.excerpt}</p>
          <p className="mt-3 flex items-center gap-3 text-xs text-slate-300">
            <span>{formatDate(post.createdAt)}</span>
            <span className="inline-flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" /> {post.readingTime} min read
            </span>
          </p>
        </div>
      </article>
    );
  }

  return (
    <article className="card card-hover group flex flex-col overflow-hidden">
      <Link to={href} className="relative block aspect-[16/9] overflow-hidden" tabIndex={-1} aria-hidden="true">
        <LazyImage src={postCover(post)} alt="" priority={priority} className="transition duration-700 group-hover:scale-105" fallbackSeed={post.slug} />
        {post.sponsored && (
          <span className="absolute right-3 top-3 inline-flex items-center gap-1 rounded-full bg-amber-400 px-2.5 py-1 text-[11px] font-bold text-amber-950 shadow">
            <Megaphone className="h-3 w-3" /> Sponsored
          </span>
        )}
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="mb-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <span className="badge">{category.name}</span>
          <span>{formatDate(post.createdAt)}</span>
        </div>
        <h3 className="text-lg font-bold leading-snug">
          <Link to={href} className="transition hover:text-brand-600 dark:hover:text-brand-400">
            {post.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 text-sm text-slate-600 dark:text-slate-400">{post.excerpt}</p>
        <div className="mt-auto flex items-center justify-between pt-4 text-xs text-slate-500 dark:text-slate-400">
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3.5 w-3.5" /> {post.readingTime} min read
          </span>
          <span className="inline-flex items-center gap-1">
            <Eye className="h-3.5 w-3.5" /> {formatNumber(post.views)}
          </span>
        </div>
      </div>
    </article>
  );
}
