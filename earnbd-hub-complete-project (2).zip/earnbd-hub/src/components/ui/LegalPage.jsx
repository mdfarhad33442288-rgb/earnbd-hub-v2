import { FileText } from 'lucide-react';
import Seo from './Seo';
import PageHeader from './PageHeader';

/** Shared layout for Privacy Policy and Terms & Conditions. sections: [{ title, body: string[] }] */
export default function LegalPage({ title, description, path, updated, intro, sections }) {
  return (
    <>
      <Seo title={title} description={description} path={path} />
      <PageHeader
        eyebrow="Legal"
        title={title}
        subtitle={`Last updated: ${updated}`}
        crumbs={[{ label: title }]}
        icon={<FileText className="h-7 w-7" />}
      />
      <div className="container-page grid max-w-5xl gap-10 py-12 lg:grid-cols-[14rem_1fr]">
        <nav aria-label="On this page" className="hidden lg:block">
          <ul className="sticky top-24 space-y-2 text-sm">
            {sections.map((s, i) => (
              <li key={s.title}>
                <a href={`#s${i + 1}`} className="text-slate-500 transition hover:text-brand-600 dark:text-slate-400">
                  {i + 1}. {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <article className="prose-article min-w-0">
          <p>{intro}</p>
          {sections.map((s, i) => (
            <section key={s.title} id={`s${i + 1}`}>
              <h2>
                {i + 1}. {s.title}
              </h2>
              {s.body.map((p, j) =>
                Array.isArray(p) ? (
                  <ul key={j}>
                    {p.map((li) => (
                      <li key={li}>{li}</li>
                    ))}
                  </ul>
                ) : (
                  <p key={j}>{p}</p>
                ),
              )}
            </section>
          ))}
        </article>
      </div>
    </>
  );
}
