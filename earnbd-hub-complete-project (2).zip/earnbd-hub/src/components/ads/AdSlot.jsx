import { useEffect, useRef } from 'react';
import { ADS } from '../../config/site';
import { applyConsent } from '../../lib/consent';

/**
 * Responsive Google AdSense display unit.
 *
 * slot: 'header' | 'sidebar' | 'inArticle' | 'inFeed' | 'footer'  (ids come from .env)
 *
 *  - Not configured + dev  -> dashed placeholder so you can see the placement.
 *  - Not configured + prod -> renders nothing (no empty boxes for visitors).
 *  - Configured            -> a real responsive <ins class="adsbygoogle"> unit.
 */
const MIN_HEIGHT = { header: 100, sidebar: 280, inArticle: 250, inFeed: 250, footer: 100 };

export default function AdSlot({ slot = 'sidebar', className = '' }) {
  const insRef = useRef(null);
  const slotId = ADS.slots[slot];
  const enabled = Boolean(ADS.client && slotId);
  const minHeight = MIN_HEIGHT[slot] || 250;

  useEffect(() => {
    const el = insRef.current;
    if (!enabled || !el || el.getAttribute('data-adsbygoogle-status')) return;
    try {
      applyConsent();
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (err) {
      console.warn('AdSense error:', err);
    }
  }, [enabled]);

  if (!enabled) {
    if (!import.meta.env.DEV) return null;
    return (
      <div
        className={`ad-wrap flex items-center justify-center border-2 border-dashed border-brand-200 bg-brand-50/50 text-xs font-medium text-brand-600 dark:border-brand-500/30 dark:bg-brand-500/5 dark:text-brand-300 ${className}`}
        style={{ minHeight }}
        aria-hidden="true"
      >
        Ad placeholder · “{slot}” (set VITE_ADSENSE_CLIENT & slot id)
      </div>
    );
  }

  return (
    <aside className={`ad-wrap ${className}`} aria-label="Advertisement" style={{ minHeight }}>
      <span className="ad-label">Advertisement</span>
      <ins
        ref={insRef}
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client={ADS.client}
        data-ad-slot={slotId}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </aside>
  );
}
