import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { Loader2, LogOut, ShieldAlert } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import Seo from '../ui/Seo';
import AdminLayout from './AdminLayout';

/** Only lets signed-in users with role "admin" through. */
export default function AdminGuard() {
  const { user, loading, isAdmin, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-50 dark:bg-slate-950" role="status" aria-label="Checking access">
        <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
      </div>
    );
  }

  if (!user) return <Navigate to="/admin/login" replace state={{ from: location.pathname }} />;

  if (!isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center bg-slate-50 px-4 dark:bg-slate-950">
        <Seo title="Access denied" noindex />
        <div className="card max-w-md p-8 text-center">
          <span className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-amber-50 text-amber-600 dark:bg-amber-500/10">
            <ShieldAlert className="h-7 w-7" />
          </span>
          <h1 className="text-2xl">Access denied</h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Your account ({user.email}) does not have administrator permissions. Ask an existing admin to change your role.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/" className="btn btn-outline">
              Back to site
            </Link>
            <button
              type="button"
              className="btn btn-primary"
              onClick={async () => {
                await logout();
                navigate('/admin/login');
              }}
            >
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        </div>
      </div>
    );
  }

  return <AdminLayout />;
}
