import { Outlet } from 'react-router-dom';
import { AuthProvider } from '../../context/AuthContext';
import { ToastProvider } from '../ui/Toast';

/** Wraps every /admin route with auth + toast providers (kept out of the public bundle path). */
export default function AdminRoot() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Outlet />
      </ToastProvider>
    </AuthProvider>
  );
}
