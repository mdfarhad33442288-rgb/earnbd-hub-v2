import { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { ArrowUp } from 'lucide-react';
import Header from './Header';
import Footer from './Footer';
import CookieBanner from '../ui/CookieBanner';
import { trackPageView } from '../../services/db';

function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 600);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  if (!show) return null;
  return (
    <button
      type="button"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      className="fixed bottom-5 right-5 z-40 grid h-11 w-11 animate-fade-in place-items-center rounded-full bg-brand-600 text-white shadow-glow transition hover:-translate-y-1 hover:bg-brand-700"
      aria-label="Back to top"
    >
      <ArrowUp className="h-5 w-5" />
    </button>
  );
}

/** Public site shell. Also scrolls to top and records a page view on every navigation. */
export default function Layout() {
  const { pathname } = useLocation();

  useEffect(() => {
    // Let pagination keep its own scroll handling; otherwise jump to top on a new page.
    window.scrollTo({ top: 0, left: 0 });
    trackPageView();
  }, [pathname]);

  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main id="main" className="flex-1">
        <Outlet />
      </main>
      <Footer />
      <CookieBanner />
      <BackToTop />
    </div>
  );
}
