import { Link } from 'react-router-dom';
import { Facebook, Mail, Send, Twitter, Youtube } from 'lucide-react';
import { NAV_LINKS, SITE } from '../../config/site';
import AdSlot from '../ads/AdSlot';
import Logo from '../ui/Logo';
import Newsletter from '../ui/Newsletter';

const SOCIAL = [
  { name: 'Facebook', icon: Facebook, href: SITE.social.facebook },
  { name: 'X (Twitter)', icon: Twitter, href: SITE.social.twitter },
  { name: 'YouTube', icon: Youtube, href: SITE.social.youtube },
  { name: 'Telegram', icon: Send, href: SITE.social.telegram },
];

export default function Footer() {
  return (
    <footer className="mt-20 bg-slate-950 text-slate-400">
      <div className="container-page">
        <AdSlot slot="footer" className="!mb-0 pt-6" />
      </div>
      <div className="container-page grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-1">
          <Logo light />
          <p className="mt-4 max-w-xs text-sm leading-6">{SITE.description}</p>
          <div className="mt-5 flex gap-2">
            {SOCIAL.map(({ name, icon: Icon, href }) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={name}
                className="grid h-10 w-10 place-items-center rounded-full bg-slate-800 text-slate-300 transition hover:-translate-y-0.5 hover:bg-brand-600 hover:text-white"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <nav aria-label="Explore">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest !text-white">Explore</h2>
          <ul className="space-y-2.5 text-sm">
            {NAV_LINKS.map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="transition hover:text-white">
                  {l.label}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/categories" className="transition hover:text-white">
                All Categories
              </Link>
            </li>
          </ul>
        </nav>

        <nav aria-label="Company">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest !text-white">Company</h2>
          <ul className="space-y-2.5 text-sm">
            {[
              ['/about', 'About Us'],
              ['/contact', 'Contact'],
              ['/privacy-policy', 'Privacy Policy'],
              ['/terms-and-conditions', 'Terms & Conditions'],
              ['/sitemap.xml', 'Sitemap'],
            ].map(([to, label]) => (
              <li key={to}>
                {to.endsWith('.xml') ? (
                  <a href={to} className="transition hover:text-white">
                    {label}
                  </a>
                ) : (
                  <Link to={to} className="transition hover:text-white">
                    {label}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="mb-4 text-sm font-bold uppercase tracking-widest !text-white">Newsletter</h2>
          <p className="mb-4 text-sm">Get new guides and job alerts straight to your inbox.</p>
          <Newsletter variant="inline" source="footer" />
          <a href={`mailto:${SITE.email}`} className="mt-5 inline-flex items-center gap-2 text-sm transition hover:text-white">
            <Mail className="h-4 w-4" /> {SITE.email}
          </a>
        </div>
      </div>

      <div className="border-t border-slate-800">
        <div className="container-page flex flex-col items-center justify-between gap-2 py-6 text-xs sm:flex-row">
          <p>
            © {new Date().getFullYear()} {SITE.name}. All rights reserved.
          </p>
          <p>Some links on this site are affiliate links. We may earn a commission at no extra cost to you.</p>
        </div>
      </div>
    </footer>
  );
}
