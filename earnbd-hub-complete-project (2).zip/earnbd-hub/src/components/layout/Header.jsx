import { useCallback, useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, Moon, Search, Sun, X } from 'lucide-react';
import { NAV_LINKS } from '../../config/site';
import { useTheme } from '../../context/ThemeContext';
import Logo from '../ui/Logo';
import SearchModal from '../ui/SearchModal';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { theme, toggle } = useTheme();
  const location = useLocation();

  const closeSearch = useCallback(() => setSearchOpen(false), []);

  useEffect(() => setMenuOpen(false), [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Keyboard shortcuts: "/" or Ctrl/Cmd+K opens search
  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target.tagName;
      const typing = tag === 'INPUT' || tag === 'TEXTAREA' || e.target.isContentEditable;
      if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const linkClass = ({ isActive }) =>
    `rounded-lg px-3 py-2 text-sm font-semibold transition ${
      isActive
        ? 'bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300'
        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white'
    }`;

  return (
    <>
      <a href="#main" className="sr-only z-[100] rounded-lg bg-brand-600 px-4 py-2 text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
        Skip to content
      </a>
      <header
        className={`sticky top-0 z-50 border-b transition duration-300 ${
          scrolled
            ? 'border-slate-200/80 bg-white/85 shadow-sm backdrop-blur-lg dark:border-slate-800 dark:bg-slate-950/85'
            : 'border-transparent bg-white dark:bg-slate-950'
        }`}
      >
        <div className="container-page flex h-16 items-center justify-between gap-3">
          <Logo />

          <nav className="hidden items-center gap-1 xl:flex" aria-label="Main navigation">
            {NAV_LINKS.map((l) => (
              <NavLink key={l.to} to={l.to} end={l.to === '/'} className={linkClass}>
                {l.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 text-sm text-slate-500 transition hover:border-brand-300 dark:border-slate-700 dark:bg-slate-900 dark:hover:border-brand-500 sm:w-44 sm:justify-between"
              aria-label="Search"
            >
              <span className="inline-flex items-center gap-2">
                <Search className="h-4 w-4" />
                <span className="hidden sm:inline">Search…</span>
              </span>
              <kbd className="hidden rounded border border-slate-200 px-1.5 text-[10px] font-semibold dark:border-slate-700 sm:inline">/</kbd>
            </button>

            <button
              type="button"
              onClick={toggle}
              className="grid h-10 w-10 place-items-center rounded-xl text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
              title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
            >
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>

            <Link to="/contact" className="btn btn-primary btn-sm hidden md:inline-flex">
              Contact
            </Link>

            <button
              type="button"
              onClick={() => setMenuOpen((o) => !o)}
              className="grid h-10 w-10 place-items-center rounded-xl text-slate-600 transition hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 xl:hidden"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
            >
              {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav id="mobile-menu" aria-label="Mobile navigation" className="animate-fade-in border-t border-slate-200 bg-white px-4 pb-5 pt-3 dark:border-slate-800 dark:bg-slate-950 xl:hidden">
            <div className="grid gap-1 sm:grid-cols-2">
              {[...NAV_LINKS, { label: 'About', to: '/about' }, { label: 'Contact', to: '/contact' }].map((l) => (
                <NavLink key={l.to} to={l.to} end={l.to === '/'} className={({ isActive }) => `${linkClass({ isActive })} block py-3 text-base`}>
                  {l.label}
                </NavLink>
              ))}
            </div>
          </nav>
        )}
      </header>
      <SearchModal open={searchOpen} onClose={closeSearch} />
    </>
  );
}
