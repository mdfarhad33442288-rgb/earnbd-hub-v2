import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { invalidateCache, listCategories, listPosts } from '../services/db';

const DataContext = createContext(null);

/**
 * Loads published posts + categories once and shares them with every public page.
 * That keeps navigation instant and the number of Firestore reads very low.
 * (Fine for hundreds of posts. For thousands, move to paginated Firestore queries.)
 */
export function DataProvider({ children }) {
  const [state, setState] = useState({ posts: [], categories: [], loading: true, error: null });

  const load = useCallback(async (fresh = false) => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      if (fresh) invalidateCache();
      const [posts, categories] = await Promise.all([listPosts(), listCategories()]);
      setState({ posts, categories, loading: false, error: null });
    } catch (error) {
      console.error('Failed to load content', error);
      setState((s) => ({ ...s, loading: false, error }));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const value = useMemo(() => {
    const catMap = Object.fromEntries(state.categories.map((c) => [c.slug, c]));
    return {
      ...state,
      catMap,
      featured: state.posts.filter((p) => p.featured),
      popular: [...state.posts].sort((a, b) => b.views - a.views),
      sponsored: state.posts.filter((p) => p.sponsored),
      getCategory: (slug) => catMap[slug] || { slug, name: slug || 'Uncategorized' },
      refresh: () => load(true),
    };
  }, [state, load]);

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used inside <DataProvider>');
  return ctx;
}
