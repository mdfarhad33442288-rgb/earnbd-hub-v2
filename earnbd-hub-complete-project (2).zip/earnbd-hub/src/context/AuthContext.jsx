import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { onAuthChange, signIn, signOut, signUp } from '../services/auth';

const AuthContext = createContext(null);

/** Only mounted around /admin routes, so public pages never wait for (or load) Firebase Auth. */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(
    () =>
      onAuthChange((u) => {
        setUser(u);
        setLoading(false);
      }),
    [],
  );

  const login = useCallback((email, password) => signIn(email, password), []);
  const register = useCallback((email, password, name) => signUp(email, password, name), []);
  const logout = useCallback(() => signOut(), []);

  const value = useMemo(
    () => ({ user, loading, isAdmin: user?.role === 'admin', login, register, logout }),
    [user, loading, login, register, logout],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
