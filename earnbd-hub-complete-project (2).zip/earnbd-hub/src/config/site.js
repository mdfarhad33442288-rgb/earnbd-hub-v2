const env = import.meta.env;

/** Central site configuration. Edit values here (or via .env) to rebrand the site. */
export const SITE = {
  name: 'EarnBD Hub',
  tagline: 'Learn. Earn. Grow.',
  description:
    'EarnBD Hub publishes practical, beginner-friendly guides on AI tools, online income, freelancing, job circulars and education for learners and earners in Bangladesh.',
  url: (env.VITE_SITE_URL || (typeof window !== 'undefined' ? window.location.origin : '')).replace(/\/$/, ''),
  email: env.VITE_CONTACT_EMAIL || 'contact@your-domain.com',
  locale: 'en_US',
  postsPerPage: 9,
  social: {
    facebook: 'https://facebook.com/',
    twitter: 'https://twitter.com/',
    youtube: 'https://youtube.com/',
    telegram: 'https://t.me/',
  },
};

/** Primary navigation (desktop + mobile). */
export const NAV_LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/blog', label: 'Blog' },
  { to: '/ai-tools', label: 'AI Tools' },
  { to: '/online-income', label: 'Online Income' },
  { to: '/freelancing', label: 'Freelancing' },
  { to: '/job-circular', label: 'Job Circular' },
  { to: '/education', label: 'Education' },
];

/** Secondary links shown in the mobile menu and footer. */
export const EXTRA_LINKS = [
  { to: '/categories', label: 'Categories' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
];

export const LEGAL_LINKS = [
  { to: '/privacy-policy', label: 'Privacy Policy' },
  { to: '/terms-and-conditions', label: 'Terms & Conditions' },
];

/**
 * Default categories. They are used as a fallback until categories exist in Firestore,
 * and they power the dedicated topic pages (/ai-tools, /online-income, ...).
 */
export const DEFAULT_CATEGORIES = [
  {
    id: 'ai-tools',
    slug: 'ai-tools',
    icon: 'bot',
    name: 'AI Tools',
    order: 1,
    description: 'Reviews, tutorials and prompt guides for the best AI tools.',
    intro:
      'Discover AI tools that save time, boost productivity and open new income opportunities — explained in plain language with practical examples.',
  },
  {
    id: 'online-income',
    slug: 'online-income',
    icon: 'wallet',
    name: 'Online Income',
    order: 2,
    description: 'Realistic, legitimate ways to earn money online.',
    intro:
      'Honest guides to earning online — from affiliate marketing and content creation to digital products — without get-rich-quick hype.',
  },
  {
    id: 'freelancing',
    slug: 'freelancing',
    icon: 'laptop',
    name: 'Freelancing',
    order: 3,
    description: 'Start and grow a freelance career step by step.',
    intro:
      'Everything you need to land your first client, build a portfolio, price your work and grow a sustainable freelance business.',
  },
  {
    id: 'job-circular',
    slug: 'job-circular',
    icon: 'briefcase',
    name: 'Job Circular',
    order: 4,
    description: 'Job-hunting guides, application tips and interview preparation.',
    intro:
      'Practical advice for reading job circulars, preparing applications and succeeding in interviews for government and private sector jobs.',
  },
  {
    id: 'education',
    slug: 'education',
    icon: 'graduation',
    name: 'Education',
    order: 5,
    description: 'Study techniques, free courses and skill-building resources.',
    intro:
      'Learn smarter with study techniques, free course roundups and roadmaps for building in-demand skills.',
  },
];

/** Routes that render a dedicated topic page → the category slug they show. */
export const TOPIC_ROUTES = {
  '/ai-tools': 'ai-tools',
  '/online-income': 'online-income',
  '/freelancing': 'freelancing',
  '/job-circular': 'job-circular',
  '/education': 'education',
};

/** Where a category lives on the site. */
export const categoryPath = (slug) => {
  const topic = Object.entries(TOPIC_ROUTES).find(([, s]) => s === slug);
  return topic ? topic[0] : `/category/${slug}`;
};

/** Google AdSense. Leave empty to hide ads; ids come from .env (see README → Monetization). */
export const ADS = {
  client: env.VITE_ADSENSE_CLIENT || '',
  slots: {
    header: env.VITE_ADSENSE_SLOT_HEADER || '',
    sidebar: env.VITE_ADSENSE_SLOT_SIDEBAR || '',
    inArticle: env.VITE_ADSENSE_SLOT_IN_ARTICLE || '',
    inFeed: env.VITE_ADSENSE_SLOT_IN_FEED || '',
    footer: env.VITE_ADSENSE_SLOT_FOOTER || '',
  },
};

export const GA_ID = env.VITE_GA_ID || '';

/**
 * Affiliate products. Replace each `url` with your own tracked affiliate link.
 * `icon` must be a key from components/ui/CategoryIcon.jsx.
 */
export const AFFILIATES = [
  {
    id: 'hosting',
    name: 'Fast Web Hosting',
    badge: 'Best for beginners',
    rating: '4.8',
    icon: 'globe',
    description: 'Launch a blog or portfolio on reliable SSD hosting with a free SSL certificate.',
    cta: 'Check pricing',
    url: 'https://example.com/affiliate/hosting',
  },
  {
    id: 'ai-writer',
    name: 'AI Writing Assistant',
    badge: 'Editor’s pick',
    rating: '4.7',
    icon: 'sparkles',
    description: 'Draft outlines, emails and product copy faster, with a free plan to get started.',
    cta: 'Try it free',
    url: 'https://example.com/affiliate/ai-writer',
  },
  {
    id: 'courses',
    name: 'Digital Skills Courses',
    badge: 'Top rated',
    rating: '4.6',
    icon: 'graduation',
    description: 'Project-based lessons in design, marketing and programming for beginners.',
    cta: 'Browse courses',
    url: 'https://example.com/affiliate/courses',
  },
  {
    id: 'freelance-kit',
    name: 'Freelancer Toolkit',
    badge: 'Save time',
    rating: '4.5',
    icon: 'laptop',
    description: 'Invoices, contracts and time tracking in one simple app for solo professionals.',
    cta: 'See features',
    url: 'https://example.com/affiliate/freelance-kit',
  },
];

/** Shown in the Sponsored section until you flag real posts as "Sponsored" in the admin editor. */
export const SPONSOR_FALLBACKS = [
  {
    id: 'sponsor-1',
    sponsor: 'Your brand here',
    title: 'Reach thousands of learners, freelancers and job seekers',
    excerpt: 'Sponsor a post, a newsletter slot or a category page on EarnBD Hub. Get in touch for rates.',
    url: '/contact?subject=Sponsored%20content',
  },
  {
    id: 'sponsor-2',
    sponsor: 'Partner program',
    title: 'Write a guest post for EarnBD Hub',
    excerpt: 'Share your expertise with our audience. Guest contributions are clearly labelled.',
    url: '/contact?subject=Guest%20post',
  },
];
