/**
 * Landing-page copy for the five main category pages (AI Tools, Online Income, Freelancing,
 * Job Circular, Education). The FAQs are also emitted as Schema.org FAQPage structured data.
 */
export const LANDING = {
  'ai-tools': {
    metaTitle: 'AI Tools – Guides, Prompts & Reviews',
    headline: 'AI Tools that make you faster and smarter',
    intro:
      'Discover practical AI tools for writing, design, research, coding and productivity – with simple tutorials and prompt guides anyone can follow.',
    highlights: ['Beginner tutorials', 'Prompt guides', 'Free tool lists', 'Productivity workflows'],
    faqs: [
      {
        q: 'Do I need to pay to use AI tools?',
        a: 'No. Many popular AI tools have a free plan that is enough for learning and light daily use. Paid plans usually add higher limits and extra features.',
      },
      {
        q: 'Can AI replace my skills?',
        a: 'AI is best used as an assistant. It speeds up drafts and repetitive tasks, but your judgement, creativity and fact-checking are still essential.',
      },
      {
        q: 'How do I write better prompts?',
        a: 'Be specific about the role, task, context, format and constraints you want. Our prompt guide walks through a simple five-part formula.',
      },
    ],
  },
  'online-income': {
    metaTitle: 'Online Income – Realistic Ways to Earn Money Online',
    headline: 'Realistic ways to earn money online',
    intro:
      'Honest guides to blogging, digital products, tutoring and more – with clear steps, realistic expectations and warnings about common scams.',
    highlights: ['Beginner-friendly', 'Scam warnings', 'Step-by-step plans', 'Monetisation tips'],
    faqs: [
      {
        q: 'How much can I earn online?',
        a: 'It varies widely. Most people start small and grow over months as their skills, audience or client base improves. Be wary of anyone promising guaranteed income.',
      },
      {
        q: 'Do I need to invest money to start?',
        a: 'Many methods, such as freelancing or tutoring, can start with little or no money. Spend on tools or courses only after you have validated your idea.',
      },
      {
        q: 'How do I avoid online income scams?',
        a: 'Never pay upfront fees for a job, avoid “get rich quick” schemes and research any platform before sharing personal or banking details.',
      },
    ],
  },
  freelancing: {
    metaTitle: 'Freelancing – Start & Grow Your Freelance Career',
    headline: 'Build a freelance career you control',
    intro:
      'From choosing a skill to winning your first client, learn how to create a standout profile, write proposals, set prices and manage projects.',
    highlights: ['Get your first client', 'Profile & proposals', 'Pricing guides', 'Client management'],
    faqs: [
      {
        q: 'Which freelancing skills are in demand?',
        a: 'Content writing, graphic design, video editing, web development, digital marketing and virtual assistance are consistently popular with international clients.',
      },
      {
        q: 'Can I freelance with no experience?',
        a: 'Yes. Build a small portfolio with practice projects, create a clear profile and start with smaller jobs to collect reviews.',
      },
      {
        q: 'How do I get paid as a freelancer?',
        a: 'Most marketplaces pay through their own platform, while direct clients may use bank transfer or other international payment services. Check fees and withdrawal rules first.',
      },
    ],
  },
  'job-circular': {
    metaTitle: 'Job Circular – Application Guides & Preparation Tips',
    headline: 'Job circular guides & preparation tips',
    intro:
      'Learn how to read a job circular, prepare your documents and apply correctly. Always confirm details on the employer’s official notice.',
    highlights: ['Application guides', 'CV & interview tips', 'Exam preparation', 'Scam awareness'],
    faqs: [
      {
        q: 'Where should I verify a job circular?',
        a: 'Always confirm the details on the official website or notice of the employer or recruiting authority before applying.',
      },
      {
        q: 'Do employers charge application fees?',
        a: 'Some official exams have a published application fee, but genuine employers never ask for payment to “guarantee” a job or interview.',
      },
      {
        q: 'What documents should I keep ready?',
        a: 'Keep a clean CV, scanned certificates, photographs, identification documents and any required experience letters in one folder.',
      },
    ],
  },
  education: {
    metaTitle: 'Education – Study Tips, Scholarships & Free Learning',
    headline: 'Study smarter and learn for free',
    intro:
      'Study techniques, scholarship checklists and free online resources to help students and professionals reach their goals.',
    highlights: ['Study techniques', 'Scholarships', 'Free courses', 'Career planning'],
    faqs: [
      {
        q: 'How can I learn new skills for free?',
        a: 'Use free video lessons, open courses and practice projects. Set a weekly schedule and track your progress to stay consistent.',
      },
      {
        q: 'When should I start a scholarship application?',
        a: 'Begin researching at least six months ahead so you have time to gather documents, write essays and meet every deadline.',
      },
      {
        q: 'Are online certificates valuable?',
        a: 'Certificates help most when combined with real projects that prove your skills. Employers value what you can demonstrate.',
      },
    ],
  },
};
