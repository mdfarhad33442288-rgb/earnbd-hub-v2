import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

/** URL-driven pagination (?page=2) so pages are shareable and crawlable. */
export function usePagination(items, perPage) {
  const [params, setParams] = useSearchParams();
  const totalPages = Math.max(1, Math.ceil(items.length / perPage));
  const requested = parseInt(params.get('page') || '1', 10);
  const page = Number.isFinite(requested) ? Math.min(Math.max(1, requested), totalPages) : 1;

  const pageItems = useMemo(() => items.slice((page - 1) * perPage, page * perPage), [items, page, perPage]);

  const setPage = useCallback(
    (next) => {
      const p = new URLSearchParams(params);
      if (next <= 1) p.delete('page');
      else p.set('page', String(next));
      setParams(p);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    [params, setParams],
  );

  return { page, totalPages, pageItems, setPage };
}
