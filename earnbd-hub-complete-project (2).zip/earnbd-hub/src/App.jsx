import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Home from './pages/Home';
import { PostGridSkeleton } from './components/ui/Skeletons';

/**
 * Route-level code splitting: every page except Home is loaded on demand, and the whole admin
 * area (plus Firebase Auth) lives in its own chunks that public visitors never download.
 */
const Blog = lazy(() => import('./pages/Blog'));
const SinglePost = lazy(() => import('./pages/SinglePost'));
const Search = lazy(() => import('./pages/Search'));
const Categories = lazy(() => import('./pages/Categories'));
const CategoryPage = lazy(() => import('./pages/CategoryPage'));
const About = lazy(() => import('./pages/About'));
const Contact = lazy(() => import('./pages/Contact'));
const PrivacyPolicy = lazy(() => import('./pages/PrivacyPolicy'));
const TermsConditions = lazy(() => import('./pages/TermsConditions'));
const NotFound = lazy(() => import('./pages/NotFound'));

const AdminRoot = lazy(() => import('./components/admin/AdminRoot'));
const AdminGuard = lazy(() => import('./components/admin/AdminGuard'));
const AdminLogin = lazy(() => import('./pages/admin/AdminLogin'));
const AdminDashboard = lazy(() => import('./pages/admin/AdminDashboard'));
const AdminPosts = lazy(() => import('./pages/admin/AdminPosts'));
const AdminPostEditor = lazy(() => import('./pages/admin/AdminPostEditor'));
const AdminCategories = lazy(() => import('./pages/admin/AdminCategories'));
const AdminUsers = lazy(() => import('./pages/admin/AdminUsers'));
const AdminAnalytics = lazy(() => import('./pages/admin/AdminAnalytics'));
const AdminInbox = lazy(() => import('./pages/admin/AdminInbox'));

function PageFallback() {
  return (
    <div className="container-page py-12" role="status" aria-label="Loading">
      <div className="skeleton mb-3 h-4 w-40" />
      <div className="skeleton mb-8 h-9 w-2/3 max-w-lg" />
      <PostGridSkeleton count={3} />
    </div>
  );
}

export default function App() {
  return (
    <Suspense fallback={<PageFallback />}>
      <Routes>
        {/* Public website */}
        <Route element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="blog" element={<Blog />} />
          <Route path="blog/:slug" element={<SinglePost />} />
          <Route path="search" element={<Search />} />
          <Route path="categories" element={<Categories />} />
          <Route path="category/:slug" element={<CategoryPage />} />

          {/* Dedicated topic landing pages */}
          <Route path="ai-tools" element={<CategoryPage slug="ai-tools" />} />
          <Route path="online-income" element={<CategoryPage slug="online-income" />} />
          <Route path="freelancing" element={<CategoryPage slug="freelancing" />} />
          <Route path="job-circular" element={<CategoryPage slug="job-circular" />} />
          <Route path="education" element={<CategoryPage slug="education" />} />

          <Route path="about" element={<About />} />
          <Route path="contact" element={<Contact />} />
          <Route path="privacy-policy" element={<PrivacyPolicy />} />
          <Route path="terms-and-conditions" element={<TermsConditions />} />
          <Route path="*" element={<NotFound />} />
        </Route>

        {/* Admin area */}
        <Route path="admin" element={<AdminRoot />}>
          <Route path="login" element={<AdminLogin />} />
          <Route element={<AdminGuard />}>
            <Route index element={<AdminDashboard />} />
            <Route path="posts" element={<AdminPosts />} />
            <Route path="posts/new" element={<AdminPostEditor />} />
            <Route path="posts/:id/edit" element={<AdminPostEditor />} />
            <Route path="categories" element={<AdminCategories />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="analytics" element={<AdminAnalytics />} />
            <Route path="inbox" element={<AdminInbox />} />
          </Route>
        </Route>
      </Routes>
    </Suspense>
  );
}
